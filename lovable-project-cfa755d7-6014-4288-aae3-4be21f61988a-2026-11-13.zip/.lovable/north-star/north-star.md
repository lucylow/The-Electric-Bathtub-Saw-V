<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Players learn how real circuits work and enjoy figuring them out.

## Metric

Locks released each week
