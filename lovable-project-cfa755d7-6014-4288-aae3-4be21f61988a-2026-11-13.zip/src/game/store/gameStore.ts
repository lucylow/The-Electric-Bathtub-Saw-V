import { create } from "zustand";
import type { Difficulty, Discovery, GameSave } from "../types";
import { discoveries as baseDiscoveries } from "../data/story";

const SAVE_KEY = "electric-bathtub-save-v1";
const defaultSave: GameSave = {
  version: 1, started: false, completed: false, unlockedLocks: [], discovered: [],
  attempts: 0, hintsUsed: 0, score: 0, difficulty: "story", lastSaved: Date.now()
};
interface GameState extends GameSave {
  activePanel: "circuit" | "notebook" | "inventory" | "settings" | null;
  discoveries: Discovery[];
  message: string;
  reducedMotion: boolean;
  setReducedMotion: (on: boolean) => void;
  setDifficulty: (difficulty: Difficulty) => void;
  start: () => void;
  setPanel: (panel: GameState["activePanel"]) => void;
  setMessage: (message: string) => void;
  attempt: () => void;
  unlock: (index: number) => void;
  discover: (id: string) => void;
  useHint: () => void;
  reset: () => void;
  save: () => void;
  load: () => void;
}
export const useGameStore = create<GameState>((set, get) => ({
  ...defaultSave, activePanel: null, discoveries: baseDiscoveries, message: "SYSTEM STANDBY",
  reducedMotion: false,
  setReducedMotion: reducedMotion => { set({ reducedMotion }); try { localStorage.setItem("electric-bathtub-reduced-motion", reducedMotion ? "1" : "0"); } catch {} },
  setDifficulty: difficulty => set({ difficulty }),
  start: () => { set({ started: true, message: "EXPERIMENT 001 INITIALIZED" }); get().save(); },
  setPanel: activePanel => set({ activePanel }),
  setMessage: message => set({ message }),
  attempt: () => set(s => ({ attempts: s.attempts + 1 })),
  unlock: index => {
    const current = get().unlockedLocks;
    if (current.includes(index)) return;
    set(s => ({ unlockedLocks: [...s.unlockedLocks, index], score: s.score + 100, message: `LOCK ${String(index + 1).padStart(2, "0")} RELEASED` }));
    if (get().unlockedLocks.length === 5) set({ completed: true, message: "EXPERIMENT 001 COMPLETE" });
    get().save();
  },
  discover: id => {
    const found = get().discoveries.map(d => d.id === id ? { ...d, found: true } : d);
    set({ discoveries: found, discovered: [...new Set([...get().discovered, id])] });
    get().save();
  },
  useHint: () => set(s => ({ hintsUsed: s.hintsUsed + 1, score: Math.max(0, s.score - 10) })),
  reset: () => { localStorage.removeItem(SAVE_KEY); set({ ...defaultSave, activePanel: null, discoveries: baseDiscoveries, message: "NEW EXPERIMENT READY" }); },
  save: () => {
    const s = get();
    const payload: GameSave = { version: 1, started: s.started, completed: s.completed, unlockedLocks: s.unlockedLocks, discovered: s.discovered, attempts: s.attempts, hintsUsed: s.hintsUsed, score: s.score, difficulty: s.difficulty, lastSaved: Date.now() };
    localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
  },
  load: () => {
    try {
      set({ reducedMotion: localStorage.getItem("electric-bathtub-reduced-motion") === "1" });
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as GameSave;
      if (parsed.version !== 1) return;
      set({ ...parsed, activePanel: null, discoveries: baseDiscoveries.map(d => ({ ...d, found: parsed.discovered.includes(d.id) })) });
    } catch { set({ message: "SAVE DATA COULD NOT BE READ" }); }
  }
}));