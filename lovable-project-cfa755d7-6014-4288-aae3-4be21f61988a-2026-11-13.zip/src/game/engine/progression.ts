import type { GameSave } from "../types";
export function getNextObjective(save: GameSave): string {
  if (save.completed) return "Review the experiment log and debrief.";
  const next = save.unlockedLocks.length;
  return [
    "Restore continuity in the first virtual loop.",
    "Use Ohm's law to select a valid virtual load.",
    "Trace the five paths and compare branch behaviour.",
    "Explain how the relay's coil controls its contacts.",
    "Diagnose the final virtual network fault."
  ][next] ?? "Continue the experiment.";
}
export function awardForAttempt(correct: boolean, hintsUsed: number) {
  if (!correct) return 0;
  return Math.max(25, 100 - hintsUsed * 10);
}