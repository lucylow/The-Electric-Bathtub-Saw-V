import { describe, expect, it } from "vitest";
import { solveLoop } from "./circuit";
import { initialCircuit } from "../data/puzzles";
describe("virtual loop solver", () => {
  it("reports an open circuit when the switch is open", () => {
    expect(solveLoop(initialCircuit).complete).toBe(false);
    expect(solveLoop(initialCircuit).message).toBe("OPEN CIRCUIT");
  });
  it("calculates current for a closed loop", () => {
    const closed = initialCircuit.map(p => p.kind === "switch" ? {...p, closed:true} : p);
    const result = solveLoop(closed);
    expect(result.complete).toBe(true);
    expect(result.current).toBeCloseTo(1.2);
    expect(result.resistance).toBe(10);
  });
});