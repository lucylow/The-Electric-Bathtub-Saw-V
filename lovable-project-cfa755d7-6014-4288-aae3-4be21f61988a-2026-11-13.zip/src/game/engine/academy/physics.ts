// Ideal-model circuit math used by the Academy labs. All SI units.
export const series = (rs: number[]) => rs.reduce((a, b) => a + b, 0);
export const parallel = (rs: number[]) => (rs.some(r => r === 0) ? 0 : 1 / rs.reduce((a, r) => a + 1 / r, 0));
export const ohm = { I: (V: number, R: number) => V / R, V: (I: number, R: number) => I * R, R: (V: number, I: number) => V / I };
export const power = (V: number, I: number) => V * I;
export const dividerV = (Vs: number, R1: number, R2: number) => ({ v1: (Vs * R1) / (R1 + R2), v2: (Vs * R2) / (R1 + R2) });
export const dividerI = (It: number, R1: number, R2: number) => ({ i1: (It * R2) / (R1 + R2), i2: (It * R1) / (R1 + R2) });
/** Loaded divider: R2 in parallel with a load (e.g. a voltmeter's input resistance). */
export const loadedDivider = (Vs: number, R1: number, R2: number, Rload: number) => {
  const r2eff = parallel([R2, Rload]);
  return (Vs * r2eff) / (R1 + r2eff);
};
export const rcCharge = (Vs: number, R: number, C: number, t: number) => Vs * (1 - Math.exp(-t / (R * C)));
export const rcDischarge = (V0: number, R: number, C: number, t: number) => V0 * Math.exp(-t / (R * C));
export const capEnergy = (C: number, V: number) => 0.5 * C * V * V;
export const reactanceC = (f: number, C: number) => 1 / (2 * Math.PI * f * C);
export const reactanceL = (f: number, L: number) => 2 * Math.PI * f * L;
/** Series RLC impedance magnitude and phase (degrees, positive = inductive). */
export const seriesImpedance = (R: number, XL: number, XC: number) => {
  const X = XL - XC;
  return { Z: Math.hypot(R, X), phase: (Math.atan2(X, R) * 180) / Math.PI };
};
export const rms = (Vpeak: number) => Vpeak / Math.SQRT2;
export const ledResistor = (Vs: number, Vf: number, I: number) => (Vs - Vf) / I;
/** Max power to load from a Thevenin source. */
export const loadPower = (Vth: number, Rth: number, RL: number) => { const I = Vth / (Rth + RL); return I * I * RL; };
export const kclUnknown = (entering: number[], leaving: number[]) => series(entering) - series(leaving);
export type Gate = "AND" | "OR" | "NAND" | "NOR" | "XOR" | "XNOR" | "NOT";
export const gate = (g: Gate, a: boolean, b: boolean) => {
  switch (g) {
    case "AND": return a && b; case "OR": return a || b; case "NAND": return !(a && b);
    case "NOR": return !(a || b); case "XOR": return a !== b; case "XNOR": return a === b; case "NOT": return !a;
  }
};
export const halfAdder = (a: boolean, b: boolean) => ({ sum: a !== b, carry: a && b });
export const adc = (vin: number, vref: number, bits: number) => Math.max(0, Math.min(2 ** bits - 1, Math.floor((vin / vref) * 2 ** bits)));

const PREFIX: [number, string][] = [[1e6, "M"], [1e3, "k"], [1, ""], [1e-3, "m"], [1e-6, "µ"], [1e-9, "n"]];
export const si = (v: number, unit: string, digits = 3) => {
  if (!isFinite(v)) return `∞ ${unit}`;
  if (v === 0) return `0 ${unit}`;
  const [m, p] = PREFIX.find(([m]) => Math.abs(v) >= m) ?? PREFIX[PREFIX.length - 1]!;
  return `${Number((v / m).toPrecision(digits))} ${p}${unit}`;
};
/** Answer within relative tolerance (default 2%). */
export const close = (got: number, want: number, tol = 0.02) => Math.abs(got - want) <= Math.max(Math.abs(want) * tol, 1e-9);
