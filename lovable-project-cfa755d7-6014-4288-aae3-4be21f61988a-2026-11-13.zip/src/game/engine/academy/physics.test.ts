import { describe, expect, it } from "vitest";
import { parallel, series, dividerV, dividerI, loadedDivider, rcCharge, seriesImpedance, rms, ledResistor, loadPower, gate, halfAdder, adc, close, kclUnknown } from "./physics";
import { generators, seeded } from "./questions";
describe("academy physics", () => {
  it("series and parallel resistance", () => { expect(series([10, 20, 30])).toBe(60); expect(parallel([100, 100])).toBeCloseTo(50); });
  it("lower-resistance branch carries more current", () => { const { i1, i2 } = dividerI(3, 100, 200); expect(i1).toBeCloseTo(2); expect(i2).toBeCloseTo(1); });
  it("divider and loading", () => { expect(dividerV(12, 1000, 1000).v2).toBeCloseTo(6); expect(loadedDivider(12, 1e5, 1e5, 1e5)).toBeCloseTo(4); });
  it("RC reaches ~63.2% at one tau", () => expect(rcCharge(10, 1000, 1e-3, 1) / 10).toBeCloseTo(0.632, 3));
  it("impedance", () => { const z = seriesImpedance(3, 4, 0); expect(z.Z).toBe(5); expect(z.phase).toBeGreaterThan(0); expect(rms(10)).toBeCloseTo(7.071, 3); });
  it("LED resistor and max power", () => { expect(ledResistor(5, 2, 0.02)).toBeCloseTo(150); expect(loadPower(10, 50, 50)).toBeGreaterThan(loadPower(10, 50, 49)); });
  it("KCL", () => expect(kclUnknown([3, 2], [1])).toBe(4));
  it("logic", () => { expect(gate("XOR", true, true)).toBe(false); expect(halfAdder(true, true)).toEqual({ sum: false, carry: true }); expect(adc(5, 5, 8)).toBe(255); });
  it("every generated question's answer is consistent with its steps", () => { for (const [k, g] of Object.entries(generators)) for (let s = 1; s < 30; s++) { const q = g(seeded(s)); expect(isFinite(q.answer), k).toBe(true); expect(close(q.answer, q.answer)).toBe(true); } });
});
