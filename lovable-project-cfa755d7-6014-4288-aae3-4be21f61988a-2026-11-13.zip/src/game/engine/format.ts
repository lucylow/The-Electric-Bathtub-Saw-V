export function formatMetric(value: number, unit: string, digits = 2) {
  if (!Number.isFinite(value)) return `— ${unit}`;
  return `${value.toFixed(digits)} ${unit}`;
}
export function formatClock(seconds: number) {
  const safe = Math.max(0, Math.floor(seconds));
  return `${String(Math.floor(safe / 60)).padStart(2,"0")}:${String(safe % 60).padStart(2,"0")}`;
}