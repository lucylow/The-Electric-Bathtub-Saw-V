export const conceptCards = {
  continuity: { title:"Continuity", formula:"closed path", explanation:"In an ideal circuit model, a continuous conductive path allows current to flow when a source establishes a potential difference." },
  ohmsLaw: { title:"Ohm's law", formula:"V = I × R", explanation:"For an ohmic element under the modeled conditions, voltage equals current multiplied by resistance." },
  series: { title:"Series resistance", formula:"Rₜ = R₁ + R₂ + …", explanation:"Elements connected in one series path carry the same current. Their ideal resistances add." },
  parallel: { title:"Parallel branches", formula:"1/Rₜ = 1/R₁ + 1/R₂ + …", explanation:"Parallel elements share the same voltage across their terminals. Branch currents depend on branch resistance." },
  power: { title:"Electrical power", formula:"P = V × I", explanation:"Power is the rate of energy transfer. In a resistor, P can also be written as I²R or V²/R." },
  relay: { title:"Electromagnetic relay", formula:"coil → magnetic field → contacts", explanation:"A relay uses a coil-generated magnetic field to move contacts. The control and switched sides are conceptually distinct." }
} as const;