import type { CircuitComponent, SimulationResult } from "../types";

/**
 * Educational DC loop solver for the game's deliberately constrained first experiment.
 * This is a simplified single-loop model, not a general-purpose electrical design tool.
 * It only evaluates isolated, low-voltage virtual components.
 */
export function solveLoop(parts: CircuitComponent[]): SimulationResult {
  const source = parts.find(p => p.kind === "source");
  const load = parts.find(p => p.kind === "resistor");
  const switchPart = parts.find(p => p.kind === "switch");
  const fuse = parts.find(p => p.kind === "fuse");
  const lamp = parts.find(p => p.kind === "lamp");
  if (!source || !load || !switchPart || !fuse || !lamp) {
    return result(false, false, 0, 0, 0, 0, "MISSING COMPONENT", "The virtual loop is missing a required element. Inspect the component tray.");
  }
  if (!switchPart.closed) {
    return result(true, false, source.value, Infinity, 0, 0, "OPEN CIRCUIT", "The switch is open. The path is interrupted, so steady-state current is zero.");
  }
  if (fuse.value <= 0 || load.value <= 0 || source.value <= 0) {
    return result(false, false, source.value, 0, 0, 0, "INVALID MODEL", "Component values must be positive in this simplified DC experiment.");
  }
  const resistance = load.value + lamp.value;
  const current = source.value / resistance;
  const power = current * current * load.value;
  const complete = current > 0.05 && current < 2.5 && fuse.value >= current;
  return result(true, complete, source.value, resistance, current, power,
    complete ? "CONTINUITY CONFIRMED" : "DIAGNOSTIC OUT OF RANGE",
    complete
      ? `Ohm's law: I = V / R = ${source.value.toFixed(1)} V / ${resistance.toFixed(1)} Ω = ${current.toFixed(2)} A. The virtual indicator receives current through a complete loop.`
      : "The simulated current is outside the target window or the virtual protection rating is insufficient. Recheck resistance and component ratings.");
}
function result(valid: boolean, complete: boolean, voltage: number, resistance: number, current: number, power: number, message: string, explanation: string): SimulationResult {
  return { valid, complete, voltage, resistance, current, power, message, explanation };
}

export function calculateOhms(voltage: number, resistance: number) {
  if (resistance <= 0) return { current: 0, power: 0 };
  const current = voltage / resistance;
  return { current, power: voltage * current };
}

export function validateContinuity(components: CircuitComponent[]) {
  const switchPart = components.find(c => c.kind === "switch");
  return Boolean(switchPart?.closed);
}