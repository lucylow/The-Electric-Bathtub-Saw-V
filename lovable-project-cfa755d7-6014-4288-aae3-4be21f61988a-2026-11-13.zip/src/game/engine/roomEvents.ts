export type RoomEvent = "crt_flicker" | "lights_dip" | "distant_impact" | "door_mechanism" | "silence";
export interface EventDefinition { id: RoomEvent; trigger: string; intensity: "low"|"medium"|"high"; }
export const roomEvents: EventDefinition[] = [
  { id:"crt_flicker", trigger:"first_discovery", intensity:"low" },
  { id:"lights_dip", trigger:"first_failed_attempt", intensity:"medium" },
  { id:"distant_impact", trigger:"second_lock_released", intensity:"medium" },
  { id:"door_mechanism", trigger:"all_locks_released", intensity:"high" },
  { id:"silence", trigger:"final_transmission", intensity:"high" }
];
export function eventsForTrigger(trigger: string) { return roomEvents.filter(event => event.trigger === trigger); }