import type { GameSave } from "../types";
const KEY = "electric-bathtub-save-v1";
export function readSave(): GameSave | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const value = JSON.parse(raw) as GameSave;
    if (value.version !== 1 || !Array.isArray(value.unlockedLocks)) return null;
    return value;
  } catch { return null; }
}
export function writeSave(value: GameSave) {
  localStorage.setItem(KEY, JSON.stringify({ ...value, lastSaved: Date.now() }));
}
export function clearSave() { localStorage.removeItem(KEY); }