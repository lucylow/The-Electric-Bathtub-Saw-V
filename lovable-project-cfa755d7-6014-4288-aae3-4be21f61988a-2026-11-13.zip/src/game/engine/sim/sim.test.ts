import { describe, expect, it } from "vitest";
import { ohm, parseUnit, series, parallel, power, reduce, solve, kclResiduals, kvlLoop, instruments, measure, type Circuit } from "./index";

const loop = (closed: boolean): Circuit => ({ ground: "g", nodes: ["g", "a", "b", "c"], edges: [
  { id: "bat", kind: "source", from: "g", to: "a", value: 12 },
  { id: "sw", kind: "switch", from: "a", to: "b", value: 0, closed },
  { id: "r1", kind: "resistor", from: "b", to: "c", value: 4 },
  { id: "lamp", kind: "lamp", from: "c", to: "g", value: 6 },
] });

describe("Ohm's law", () => {
  it("solves each form", () => {
    expect(ohm({ V: 12, R: 10 }).I).toBeCloseTo(1.2);
    expect(ohm({ I: 2, R: 5 }).V).toBe(10);
    expect(ohm({ V: 9, I: 3 }).R).toBe(3);
  });
  it("rejects zero resistance, zero current and bad input", () => {
    expect(() => ohm({ V: 5, R: 0 })).toThrow();
    expect(() => ohm({ V: 5, I: 0 })).toThrow();
    expect(() => ohm({ V: -1, R: 2 })).toThrow();
    expect(() => ohm({ V: 1 })).toThrow();
  });
  it("converts units", () => { expect(parseUnit("4.7 kΩ")).toBe(4700); expect(parseUnit("250 mA")).toBeCloseTo(0.25); });
});

describe("series and parallel", () => {
  it("series drops sum to source", () => { const s = series(12, [2, 4]); expect(s.R).toBe(6); expect(s.I).toBe(2); expect(s.drops).toEqual([4, 8]); expect(s.kvlOk).toBe(true); });
  it("parallel branches sum to total", () => { const p = parallel(12, [6, 3]); expect(p.R).toBeCloseTo(2); expect(p.branch).toEqual([2, 4]); expect(p.kclOk).toBe(true); });
  it("reduces combinations", () => expect(reduce({ s: [2, { p: [6, 3] }] }).R).toBeCloseTo(4));
  it("power forms agree", () => { expect(power.vi(12, 2)).toBe(24); expect(power.i2r(2, 6)).toBe(24); expect(power.v2r(12, 6)).toBe(24); });
});

describe("nodal solver", () => {
  it("closed loop: 12 V / 10 Ω = 1.2 A", () => {
    const c = loop(true), s = solve(c);
    expect(s.ok).toBe(true);
    expect(instruments.ammeter(s, "r1")).toBeCloseTo(1.2, 4);
    expect(instruments.voltmeter(s, "b", "c")).toBeCloseTo(4.8, 4);
    expect(instruments.powerMeter(s, "lamp")).toBeCloseTo(8.64, 3);
    Object.values(kclResiduals(c, s)).forEach(r => expect(Math.abs(r)).toBeLessThan(1e-6));
    expect(Math.abs(kvlLoop(s, ["g", "a", "b", "c"]))).toBeLessThan(1e-9);
  });
  it("open switch gives zero current and no continuity", () => {
    const c = loop(false), s = solve(c);
    expect(instruments.ammeter(s, "r1")).toBeCloseTo(0, 6);
    expect(instruments.continuity(c, "a", "b")).toBe(false);
  });
  it("parallel network matches formula", () => {
    const c: Circuit = { ground: "g", nodes: ["g", "a"], edges: [
      { id: "v", kind: "source", from: "g", to: "a", value: 12 },
      { id: "r1", kind: "resistor", from: "a", to: "g", value: 6 },
      { id: "r2", kind: "resistor", from: "a", to: "g", value: 3 } ] };
    const s = solve(c);
    expect(s.edges.r1.current).toBeCloseTo(2); expect(s.edges.r2.current).toBeCloseTo(4); expect(s.edges.v.current).toBeCloseTo(6);
  });
  it("rejects invalid parts", () => expect(solve({ ...loop(true), edges: [...loop(true).edges, { id: "x", kind: "resistor", from: "a", to: "zz", value: 1 }] }).ok).toBe(false));
});

describe("measurement error", () => {
  it("stays within the meter's stated error and resolution", () => {
    for (const r of [0, 0.5, 1]) { const m = measure(5, undefined, () => r); expect(Math.abs(m.reading - 5)).toBeLessThanOrEqual(m.maxError); }
  });
});
