/**
 * Educational DC circuit engine (virtual, isolated, low-voltage only).
 * Graph model + nodal analysis, Ohm/series/parallel/reduction helpers,
 * Kirchhoff checks, power, virtual instruments and measurement error.
 */
export type NodeId = string;
export type EdgeKind = "resistor" | "source" | "switch" | "wire" | "lamp" | "fuse";
export interface Edge { id: string; kind: EdgeKind; from: NodeId; to: NodeId; value: number; closed?: boolean; label?: string }
export interface Circuit { nodes: NodeId[]; edges: Edge[]; ground: NodeId }
export interface Step { formula: string; result: string }
export interface EdgeResult { id: string; voltage: number; current: number; power: number }
export interface Solution { ok: boolean; error?: string; nodeVoltages: Record<NodeId, number>; edges: Record<string, EdgeResult> }

const EPS = 1e-9;
const WIRE_R = 1e-6;
export const round = (n: number, d = 4) => Math.round(n * 10 ** d) / 10 ** d;
const fmt = (n: number, u: string) => `${round(n, 3)} ${u}`;

/* ---- Ohm's law (PAGE 022) ---- */
type OhmIn = { V?: number; I?: number; R?: number };
export function ohm(input: OhmIn): { V: number; I: number; R: number; step: Step } {
  const { V, I, R } = input;
  const bad = (x?: number) => x !== undefined && (!Number.isFinite(x) || x < 0);
  if (bad(V) || bad(I) || bad(R)) throw new Error("Values must be finite and non-negative");
  if (V === undefined && I !== undefined && R !== undefined) return { V: I * R, I, R, step: { formula: "V = I × R", result: `${fmt(I, "A")} × ${fmt(R, "Ω")} = ${fmt(I * R, "V")}` } };
  if (I === undefined && V !== undefined && R !== undefined) {
    if (R <= EPS) throw new Error("Zero resistance: current is undefined (short circuit)");
    return { V, I: V / R, R, step: { formula: "I = V / R", result: `${fmt(V, "V")} / ${fmt(R, "Ω")} = ${fmt(V / R, "A")}` } };
  }
  if (R === undefined && V !== undefined && I !== undefined) {
    if (I <= EPS) throw new Error("Zero current: resistance is undefined (open circuit)");
    return { V, I, R: V / I, step: { formula: "R = V / I", result: `${fmt(V, "V")} / ${fmt(I, "A")} = ${fmt(V / I, "Ω")}` } };
  }
  throw new Error("Provide exactly two of V, I, R");
}
const PREFIX: Record<string, number> = { "": 1, m: 1e-3, k: 1e3, M: 1e6, "µ": 1e-6, u: 1e-6 };
export function parseUnit(text: string): number {
  const m = text.trim().match(/^(-?\d*\.?\d+)\s*([mkMµu]?)\s*(V|A|Ω|ohm|W)?$/);
  if (!m) throw new Error(`Cannot read value "${text}"`);
  return Number(m[1]) * PREFIX[m[2]];
}

/* ---- Series / parallel / power (PAGES 023, 024, 028) ---- */
export function series(V: number, rs: number[]) {
  if (!rs.length || rs.some(r => r <= 0)) throw new Error("Series resistors must be positive");
  const R = rs.reduce((a, b) => a + b, 0), I = V / R;
  const drops = rs.map(r => I * r);
  const sum = drops.reduce((a, b) => a + b, 0);
  return { R, I, drops, kvlOk: Math.abs(sum - V) < 1e-6,
    steps: [{ formula: "R_total = R1 + R2 + … + Rn", result: `${rs.join(" + ")} = ${fmt(R, "Ω")}` }, { formula: "I = V / R_total", result: `${fmt(V, "V")} / ${fmt(R, "Ω")} = ${fmt(I, "A")}` }] as Step[] };
}
export function parallel(V: number, rs: number[]) {
  if (!rs.length || rs.some(r => r <= 0)) throw new Error("Parallel resistors must be positive");
  const R = 1 / rs.reduce((a, r) => a + 1 / r, 0);
  const branch = rs.map(r => V / r), I = V / R;
  return { R, I, branch, kclOk: Math.abs(branch.reduce((a, b) => a + b, 0) - I) < 1e-6,
    steps: [{ formula: "1/R_total = 1/R1 + … + 1/Rn", result: `R_total = ${fmt(R, "Ω")}` }, { formula: "I = V / R_total", result: fmt(I, "A") }] as Step[] };
}
export const power = {
  vi: (V: number, I: number) => V * I,
  i2r: (I: number, R: number) => I * I * R,
  v2r: (V: number, R: number) => { if (R <= EPS) throw new Error("Zero resistance"); return V * V / R; },
};

/* ---- Combination reduction (PAGE 025) ---- */
export type Net = number | { s: Net[] } | { p: Net[] };
export function reduce(net: Net, steps: Step[] = []): { R: number; steps: Step[] } {
  if (typeof net === "number") return { R: net, steps };
  const parts = ("s" in net ? net.s : net.p).map(n => reduce(n, steps).R);
  const R = "s" in net ? parts.reduce((a, b) => a + b, 0) : 1 / parts.reduce((a, r) => a + 1 / r, 0);
  steps.push({ formula: "s" in net ? "series" : "parallel", result: `${parts.map(p => round(p, 3)).join("s" in net ? " + " : " ∥ ")} = ${fmt(R, "Ω")}` });
  return { R, steps };
}

/* ---- Graph utilities + nodal solver (PAGES 021, 026, 027) ---- */
export const neighbours = (c: Circuit, n: NodeId) => c.edges.filter(e => e.kind !== "source" && conducts(e) && (e.from === n || e.to === n)).map(e => (e.from === n ? e.to : e.from));
export function connected(c: Circuit, a: NodeId, b: NodeId) {
  const seen = new Set([a]), q = [a];
  while (q.length) { const n = q.shift()!; if (n === b) return true; for (const m of neighbours(c, n)) if (!seen.has(m)) { seen.add(m); q.push(m); } }
  return false;
}
const conducts = (e: Edge) => !((e.kind === "switch" && !e.closed) || (e.kind === "fuse" && e.closed === false));
const resistanceOf = (e: Edge) => (e.kind === "wire" || e.kind === "switch" || e.kind === "fuse" ? WIRE_R : e.value);

function gauss(A: number[][], b: number[]): number[] | null {
  const n = b.length, M = A.map((r, i) => [...r, b[i]]);
  for (let c = 0; c < n; c++) {
    let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    if (Math.abs(M[p][c]) < 1e-14) return null;
    [M[c], M[p]] = [M[p], M[c]];
    for (let r = 0; r < n; r++) if (r !== c) { const f = M[r][c] / M[c][c]; for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k]; }
  }
  return M.map((r, i) => r[n] / r[i]);
}

export function solve(c: Circuit): Solution {
  const empty: Solution = { ok: false, nodeVoltages: {}, edges: {} };
  if (!c.nodes.includes(c.ground)) return { ...empty, error: "Ground node missing" };
  for (const e of c.edges) {
    if (!c.nodes.includes(e.from) || !c.nodes.includes(e.to)) return { ...empty, error: `Edge ${e.id} references an unknown node` };
    if ((e.kind === "resistor" || e.kind === "lamp") && !(e.value > 0)) return { ...empty, error: `${e.id} must have positive resistance` };
  }
  const nodes = c.nodes.filter(n => n !== c.ground);
  const idx = new Map(nodes.map((n, i) => [n, i]));
  const active = c.edges.filter(conducts);
  const sources = active.filter(e => e.kind === "source");
  const size = nodes.length + sources.length;
  const A = Array.from({ length: size }, () => Array(size).fill(0)), b = Array(size).fill(0);
  const G = 1e-12; // tiny leak to ground keeps floating nodes solvable
  nodes.forEach((_, i) => (A[i][i] += G));
  for (const e of active) if (e.kind !== "source") {
    const g = 1 / resistanceOf(e), i = idx.get(e.from), j = idx.get(e.to);
    if (i !== undefined) A[i][i] += g; if (j !== undefined) A[j][j] += g;
    if (i !== undefined && j !== undefined) { A[i][j] -= g; A[j][i] -= g; }
  }
  sources.forEach((s, k) => { // source: V(to) - V(from) = value  (to = + terminal)
    const r = nodes.length + k, i = idx.get(s.from), j = idx.get(s.to);
    if (j !== undefined) { A[j][r] += 1; A[r][j] += 1; }
    if (i !== undefined) { A[i][r] -= 1; A[r][i] -= 1; }
    b[r] = s.value;
  });
  const x = gauss(A, b);
  if (!x) return { ...empty, error: "Circuit cannot be solved (conflicting sources)" };
  const v: Record<NodeId, number> = { [c.ground]: 0 }; nodes.forEach((n, i) => (v[n] = round(x[i], 9)));
  const edges: Record<string, EdgeResult> = {};
  for (const e of c.edges) {
    const dv = v[e.from] - v[e.to];
    let I = 0;
    if (!conducts(e)) I = 0;
    else if (e.kind === "source") I = x[nodes.length + sources.indexOf(e)]; // current from + terminal into circuit is -I here
    else I = dv / resistanceOf(e);
    const current = e.kind === "source" ? -I : I;
    edges[e.id] = { id: e.id, voltage: round(e.kind === "source" ? -dv : dv, 9), current: round(current, 9), power: round(Math.abs((e.kind === "source" ? -dv : dv) * current), 9) };
  }
  return { ok: true, nodeVoltages: v, edges };
}

/** Sum of currents leaving each node (should be ~0). */
export function kclResiduals(c: Circuit, s: Solution) {
  const res: Record<NodeId, number> = Object.fromEntries(c.nodes.map(n => [n, 0]));
  for (const e of c.edges) {
    const r = s.edges[e.id]; if (!r) continue;
    // positive current flows from -> to for passive parts; for sources from + (to) out into circuit
    if (e.kind === "source") { res[e.to] -= r.current; res[e.from] += r.current; }
    else { res[e.from] += r.current; res[e.to] -= r.current; }
  }
  return res;
}
/** Walk a loop of node ids; returns sum of voltage changes (should be ~0). */
export function kvlLoop(s: Solution, loop: NodeId[]) {
  let sum = 0; for (let i = 0; i < loop.length; i++) sum += s.nodeVoltages[loop[(i + 1) % loop.length]] - s.nodeVoltages[loop[i]];
  return sum;
}

/* ---- Virtual instruments + error (PAGES 029, 030) ---- */
export interface MeterSpec { resolution: number; accuracyPct: number; offset: number; repeatability: number }
export const DEFAULT_METER: MeterSpec = { resolution: 0.01, accuracyPct: 0.5, offset: 0, repeatability: 0.002 };
export function measure(trueValue: number, spec: MeterSpec = DEFAULT_METER, rand: () => number = Math.random) {
  const noise = (rand() * 2 - 1) * (Math.abs(trueValue) * spec.accuracyPct / 100 + spec.repeatability);
  const reading = Math.round((trueValue + spec.offset + noise) / spec.resolution) * spec.resolution;
  return { reading: round(reading, 6), trueValue, maxError: Math.abs(trueValue) * spec.accuracyPct / 100 + spec.repeatability + Math.abs(spec.offset) + spec.resolution / 2 };
}
export const instruments = {
  voltmeter: (s: Solution, a: NodeId, b: NodeId) => s.nodeVoltages[a] - s.nodeVoltages[b],
  ammeter: (s: Solution, edgeId: string) => s.edges[edgeId]?.current ?? 0,
  powerMeter: (s: Solution, edgeId: string) => s.edges[edgeId]?.power ?? 0,
  /** Ohmmeter on an isolated (unpowered) part: resistance of that edge. */
  ohmmeter: (e: Edge) => (conducts(e) ? resistanceOf(e) : Infinity),
  continuity: (c: Circuit, a: NodeId, b: NodeId) => connected(c, a, b),
};
