export type Difficulty = "story" | "engineering" | "nightmare";
export type PanelTab = "circuit" | "notebook" | "inventory" | "settings";
export type ComponentKind = "source" | "resistor" | "switch" | "lamp" | "fuse" | "relay";
export interface CircuitComponent {
  id: string;
  kind: ComponentKind;
  label: string;
  value: number;
  unit: string;
  from: string;
  to: string;
  closed?: boolean;
}
export interface SimulationResult {
  valid: boolean;
  complete: boolean;
  voltage: number;
  resistance: number;
  current: number;
  power: number;
  message: string;
  explanation: string;
}
export interface Discovery {
  id: string;
  title: string;
  body: string;
  category: "document" | "clue" | "recording";
  found: boolean;
}
export interface GameSave {
  version: number;
  started: boolean;
  completed: boolean;
  unlockedLocks: number[];
  discovered: string[];
  attempts: number;
  hintsUsed: number;
  score: number;
  difficulty: Difficulty;
  lastSaved: number;
}