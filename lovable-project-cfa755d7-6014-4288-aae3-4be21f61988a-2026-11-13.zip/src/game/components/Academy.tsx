import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, GraduationCap, X, XCircle } from "lucide-react";
import { curriculum, type LabId, type Module } from "../data/curriculum";
import * as P from "../engine/academy/physics";
import { generators, seeded } from "../engine/academy/questions";

const KEY = "electric-bathtub-academy-v1";
type Progress = Record<string, { correct: number; myth?: boolean }>;
const NEEDED = 3;
const loadProgress = (): Progress => { try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { return {}; } };

function Slider({ label, value, min, max, step, onChange, fmt }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; fmt: string }) {
  return <label className="ac-slider"><span>{label}</span><input type="range" min={min} max={max} step={step} value={value} onChange={e => onChange(Number(e.target.value))} /><b>{fmt}</b></label>;
}
const Readout = ({ items }: { items: [string, string][] }) => <div className="ac-readout">{items.map(([k, v]) => <div key={k}><span>{k}</span><b>{v}</b></div>)}</div>;

function OhmLab() {
  const [V, setV] = useState(9), [R, setR] = useState(330);
  const I = P.ohm.I(V, R), pts = Array.from({ length: 25 }, (_, i) => { const r = 50 + i * 40; return [r, P.ohm.I(V, r)] as const; });
  const max = P.ohm.I(V, 50);
  return <div><p className="ac-note">Close the loop: an ideal source drives one resistor. Raise R at fixed V and watch the current fall.</p>
    <Slider label="Source V" value={V} min={1} max={24} step={0.5} onChange={setV} fmt={`${V} V`} />
    <Slider label="Resistor R" value={R} min={50} max={1010} step={10} onChange={setR} fmt={`${R} Ω`} />
    <Readout items={[["Current I = V/R", P.si(I, "A")], ["Power P = VI", P.si(P.power(V, I), "W")], ["V across R", `${V} V`]]} />
    <svg viewBox="0 0 250 90" className="ac-graph" aria-label="Current versus resistance graph"><polyline points={pts.map(([r, i]) => `${((r - 50) / 960) * 240 + 5},${85 - (i / max) * 78}`).join(" ")} /><circle cx={((R - 50) / 960) * 240 + 5} cy={85 - (I / max) * 78} r="4" /><text x="5" y="10">I</text><text x="230" y="84">R</text></svg>
  </div>;
}
function NetworkLab() {
  const [rs, setRs] = useState([100, 220, 330]);
  const s = P.series(rs), p = P.parallel(rs), V = 12;
  return <div><p className="ac-note">Same three resistors, two topologies, 12 V source. Compare.</p>
    {rs.map((r, i) => <Slider key={i} label={`R${i + 1}`} value={r} min={10} max={1000} step={10} onChange={v => setRs(rs.map((x, j) => j === i ? v : x))} fmt={`${r} Ω`} />)}
    <div className="ac-compare"><div><h4>SERIES</h4><Readout items={[["R_eq", P.si(s, "Ω")], ["I (same everywhere)", P.si(V / s, "A")], ...rs.map((r, i) => [`V_R${i + 1}`, P.si((V / s) * r, "V")] as [string, string]), ["P total", P.si(V * V / s, "W")]]} /></div>
      <div><h4>PARALLEL</h4><Readout items={[["R_eq", P.si(p, "Ω")], ["V (same on every branch)", "12 V"], ...rs.map((r, i) => [`I_R${i + 1}`, P.si(V / r, "A")] as [string, string]), ["P total", P.si(V * V / p, "W")]]} /></div></div>
  </div>;
}
function DividerLab() {
  const [R1, a] = useState(10000), [R2, b] = useState(10000), [Rm, c] = useState(6);
  const ideal = P.dividerV(12, R1, R2).v2, meas = P.loadedDivider(12, R1, R2, 10 ** Rm);
  const I = 12 / (R1 + R2);
  return <div><p className="ac-note">12 V divider. KVL check: V_R1 + V_R2 = 12 V. Now attach a real voltmeter and watch it load the output.</p>
    <Slider label="R1" value={R1} min={1000} max={1000000} step={1000} onChange={a} fmt={P.si(R1, "Ω")} />
    <Slider label="R2" value={R2} min={1000} max={1000000} step={1000} onChange={b} fmt={P.si(R2, "Ω")} />
    <Slider label="Meter R (10^x)" value={Rm} min={4} max={8} step={1} onChange={c} fmt={P.si(10 ** Rm, "Ω")} />
    <Readout items={[["V_R1", P.si(I * R1, "V")], ["V_R2 (ideal)", P.si(ideal, "V")], ["KVL sum", P.si(I * R1 + ideal, "V")], ["Meter reads", P.si(meas, "V")], ["Loading error", `${(((ideal - meas) / ideal) * 100).toFixed(1)} %`]]} />
  </div>;
}
function TheveninLab() {
  const [RL, setRL] = useState(25); const Vth = 10, Rth = 50;
  const pts = Array.from({ length: 50 }, (_, i) => { const r = 2 + i * 4; return [r, P.loadPower(Vth, Rth, r)] as const; }), max = P.loadPower(Vth, Rth, Rth);
  const Pl = P.loadPower(Vth, Rth, RL), eff = RL / (RL + Rth);
  return <div><p className="ac-note">The facility generator is a Thevenin source: 10 V behind 50 Ω. Find the load that extracts the most power.</p>
    <Slider label="Load R_L" value={RL} min={2} max={198} step={1} onChange={setRL} fmt={`${RL} Ω`} />
    <Readout items={[["Load power", P.si(Pl, "W")], ["Terminal V", P.si(Vth * RL / (RL + Rth), "V")], ["Efficiency", `${(eff * 100).toFixed(0)} %`], ["Norton I_N", P.si(Vth / Rth, "A")]]} />
    <svg viewBox="0 0 250 90" className="ac-graph"><polyline points={pts.map(([r, p]) => `${((r - 2) / 196) * 240 + 5},${85 - (p / max) * 75}`).join(" ")} /><circle cx={((RL - 2) / 196) * 240 + 5} cy={85 - (Pl / max) * 75} r="4" /><line x1={((Rth - 2) / 196) * 240 + 5} x2={((Rth - 2) / 196) * 240 + 5} y1="5" y2="85" className="ac-guide" /></svg>
    {Math.abs(RL - Rth) <= 1 && <p className="ac-good">Maximum power: R_L = R_th. Note the efficiency is only 50%.</p>}
  </div>;
}
function RcLab() {
  const [R, setR] = useState(10), [C, setC] = useState(100), [mode, setMode] = useState<"charge" | "discharge">("charge");
  const tau = R * 1000 * C * 1e-6, tMax = 5 * tau;
  const f = (t: number) => mode === "charge" ? P.rcCharge(10, R * 1000, C * 1e-6, t) : P.rcDischarge(10, R * 1000, C * 1e-6, t);
  return <div><p className="ac-note">10 V source. The curve always reaches 63.2% (or falls to 36.8%) after one τ, whatever R and C are.</p>
    <div className="ac-tabs">{(["charge", "discharge"] as const).map(m => <button key={m} className={mode === m ? "on" : ""} onClick={() => setMode(m)}>{m.toUpperCase()}</button>)}</div>
    <Slider label="R" value={R} min={1} max={100} step={1} onChange={setR} fmt={`${R} kΩ`} />
    <Slider label="C" value={C} min={1} max={1000} step={1} onChange={setC} fmt={`${C} µF`} />
    <Readout items={[["τ = RC", P.si(tau, "s")], ["V at 1τ", P.si(f(tau), "V")], ["Settled (5τ)", P.si(tMax, "s")], ["Stored energy (full)", P.si(P.capEnergy(C * 1e-6, 10), "J")]]} />
    <svg viewBox="0 0 250 90" className="ac-graph"><polyline points={Array.from({ length: 60 }, (_, i) => { const t = (i / 59) * tMax; return `${(t / tMax) * 240 + 5},${85 - (f(t) / 10) * 78}`; }).join(" ")} />{[1, 2, 3, 4].map(n => <line key={n} x1={(n / 5) * 240 + 5} x2={(n / 5) * 240 + 5} y1="5" y2="85" className="ac-guide" />)}</svg>
  </div>;
}
function AcLab() {
  const [f, setF] = useState(60), [R, setR] = useState(100), [Lm, setL] = useState(200), [Cu, setC] = useState(47);
  const XL = P.reactanceL(f, Lm / 1000), XC = P.reactanceC(f, Cu * 1e-6), z = P.seriesImpedance(R, XL, XC), Vp = 10, I = P.rms(Vp) / z.Z;
  const f0 = 1 / (2 * Math.PI * Math.sqrt((Lm / 1000) * Cu * 1e-6));
  return <div><p className="ac-note">Series RLC driven by a 10 V-peak sine. Sweep frequency to find resonance where X_L = X_C.</p>
    <Slider label="Frequency" value={f} min={5} max={500} step={1} onChange={setF} fmt={`${f} Hz`} />
    <Slider label="R" value={R} min={10} max={500} step={10} onChange={setR} fmt={`${R} Ω`} />
    <Slider label="L" value={Lm} min={10} max={1000} step={10} onChange={setL} fmt={`${Lm} mH`} />
    <Slider label="C" value={Cu} min={1} max={220} step={1} onChange={setC} fmt={`${Cu} µF`} />
    <Readout items={[["X_L", P.si(XL, "Ω")], ["X_C", P.si(XC, "Ω")], ["|Z|", P.si(z.Z, "Ω")], ["Phase", `${z.phase.toFixed(1)}° ${z.phase > 1 ? "(inductive)" : z.phase < -1 ? "(capacitive)" : "(resistive)"}`], ["I_rms", P.si(I, "A")], ["Real power", P.si(I * I * R, "W")], ["Resonance f₀", P.si(f0, "Hz")]]} />
    <svg viewBox="0 0 250 90" className="ac-graph"><polyline points={Array.from({ length: 80 }, (_, i) => `${i * 3 + 5},${45 - 35 * Math.sin(i / 8)}`).join(" ")} /><polyline className="ac-alt" points={Array.from({ length: 80 }, (_, i) => `${i * 3 + 5},${45 - 35 * Math.min(1, I / (P.rms(Vp) / R)) * Math.sin(i / 8 - (z.phase * Math.PI) / 180)}`).join(" ")} /></svg>
  </div>;
}
function LedLab() {
  const [Vs, setVs] = useState(9), [Vf, setVf] = useState(2), [R, setR] = useState(330);
  const I = Math.max(0, (Vs - Vf) / R), Pr = I * I * R, state = I > 0.03 ? "OVERCURRENT — LED DESTROYED" : I > 0.002 ? "LIT" : "TOO DIM";
  return <div><p className="ac-note">Choose a series resistor so the LED runs near 10–20 mA. Check the resistor's power rating too.</p>
    <Slider label="Supply" value={Vs} min={3} max={24} step={0.5} onChange={setVs} fmt={`${Vs} V`} />
    <Slider label="LED Vf" value={Vf} min={1.6} max={3.4} step={0.1} onChange={setVf} fmt={`${Vf.toFixed(1)} V`} />
    <Slider label="Resistor" value={R} min={10} max={2000} step={10} onChange={setR} fmt={`${R} Ω`} />
    <div className={`ac-led ${state === "LIT" ? "lit" : state.startsWith("OVER") ? "dead" : ""}`} style={{ opacity: state === "LIT" ? 0.4 + Math.min(1, I / 0.02) * 0.6 : 1 }}>{state}</div>
    <Readout items={[["LED current", P.si(I, "A")], ["Ideal R for 15 mA", P.si(P.ledResistor(Vs, Vf, 0.015), "Ω")], ["Resistor power", P.si(Pr, "W")], ["Rating needed (2× derate)", Pr * 2 > 0.25 ? "0.5 W or more" : "0.25 W OK"]]} />
  </div>;
}
function LogicLab() {
  const [g, setG] = useState<P.Gate>("XOR"); const [a, setA] = useState(false), [b, setB] = useState(false);
  const ha = P.halfAdder(a, b);
  return <div><p className="ac-note">Toggle the inputs. The truth table is computed live from the gate's Boolean function.</p>
    <div className="ac-tabs">{(["AND", "OR", "NAND", "NOR", "XOR", "XNOR", "NOT"] as P.Gate[]).map(x => <button key={x} className={g === x ? "on" : ""} onClick={() => setG(x)}>{x}</button>)}</div>
    <div className="ac-tabs"><button className={a ? "on" : ""} onClick={() => setA(!a)}>A = {+a}</button>{g !== "NOT" && <button className={b ? "on" : ""} onClick={() => setB(!b)}>B = {+b}</button>}<span className={`ac-bit ${P.gate(g, a, b) ? "on" : ""}`}>OUT = {+P.gate(g, a, b)}</span></div>
    <table className="ac-table"><thead><tr><th>A</th>{g !== "NOT" && <th>B</th>}<th>{g}</th></tr></thead><tbody>{(g === "NOT" ? [[false, false], [true, false]] : [[false, false], [false, true], [true, false], [true, true]]).map(([x, y]) => <tr key={`${x}${y}`} className={x === a && (g === "NOT" || y === b) ? "on" : ""}><td>{+x!}</td>{g !== "NOT" && <td>{+y!}</td>}<td>{+P.gate(g, x!, y!)}</td></tr>)}</tbody></table>
    <Readout items={[["Half adder SUM (A⊕B)", `${+ha.sum}`], ["Half adder CARRY (A·B)", `${+ha.carry}`]]} />
  </div>;
}
function MeterLab() {
  const [v, setV] = useState(2.5), [bits, setBits] = useState(8), vref = 5;
  const code = P.adc(v, vref, bits), lsb = vref / 2 ** bits;
  return <div><p className="ac-note">A sensor voltage enters an ADC with a 5 V reference. More bits → finer steps → smaller quantisation error.</p>
    <Slider label="Sensor V" value={v} min={0} max={5} step={0.01} onChange={setV} fmt={`${v.toFixed(2)} V`} />
    <Slider label="Resolution" value={bits} min={2} max={12} step={1} onChange={setBits} fmt={`${bits} bits`} />
    <Readout items={[["Output code", `${code} / ${2 ** bits - 1}`], ["Binary", code.toString(2).padStart(bits, "0")], ["LSB size", P.si(lsb, "V")], ["Reconstructed", P.si(code * lsb, "V")], ["Quantisation error", P.si(v - code * lsb, "V")]]} />
  </div>;
}
const UNITS: [string, number][] = [["n", 1e-9], ["µ", 1e-6], ["m", 1e-3], ["", 1], ["k", 1e3], ["M", 1e6]];
function UnitsLab() {
  const [seed, setSeed] = useState(1), [ans, setAns] = useState(""), [res, setRes] = useState<boolean | null>(null);
  const q = useMemo(() => { const r = seeded(seed * 97); const u = ["Ω", "F", "A", "V", "H", "Hz"][Math.floor(r() * 6)]!; const from = UNITS[Math.floor(r() * 6)]!, to = UNITS[Math.floor(r() * 6)]!; const val = [1, 2.2, 4.7, 10, 33, 470][Math.floor(r() * 6)]!; return { u, from, to, val, answer: (val * from[1]) / to[1] }; }, [seed]);
  return <div><p className="ac-note">Randomised unit-conversion drill. Scientific notation (e.g. 4.7e-3) is accepted.</p>
    <div className="ac-q">{q.val} {q.from[0]}{q.u} = ? {q.to[0]}{q.u}</div>
    <div className="ac-answer"><input value={ans} onChange={e => setAns(e.target.value)} onKeyDown={e => e.key === "Enter" && setRes(P.close(Number(ans), q.answer, 0.001))} aria-label="Conversion answer" /><button onClick={() => setRes(P.close(Number(ans), q.answer, 0.001))}>CHECK</button><button onClick={() => { setSeed(seed + 1); setAns(""); setRes(null); }}>NEXT</button></div>
    {res !== null && <p className={res ? "ac-good" : "ac-bad"}>{res ? "Correct." : `Not quite — ${q.answer.toPrecision(4)} ${q.to[0]}${q.u}.`}</p>}
  </div>;
}
const LABS: Record<LabId, () => React.JSX.Element> = { ohm: OhmLab, network: NetworkLab, divider: DividerLab, thevenin: TheveninLab, rc: RcLab, ac: AcLab, led: LedLab, logic: LogicLab, meter: MeterLab, units: UnitsLab };

function Assessment({ mod, onCorrect }: { mod: Module; onCorrect: () => void }) {
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 1e6)), [ans, setAns] = useState(""), [res, setRes] = useState<boolean | null>(null), [showSteps, setShow] = useState(false);
  const q = useMemo(() => generators[mod.id]!(seeded(seed)), [mod.id, seed]);
  const check = () => { if (ans.trim() === "" || res === true) return; const ok = P.close(Number(ans), q.answer); setRes(ok); if (ok) onCorrect(); else setShow(true); };
  return <div className="ac-assess"><span className="eyebrow">LOCK ASSESSMENT · RANDOMISED</span><p className="ac-q">{q.prompt}</p>
    <div className="ac-answer"><input inputMode="decimal" value={ans} onChange={e => setAns(e.target.value)} onKeyDown={e => e.key === "Enter" && check()} aria-label="Your answer" /><span>{q.unit}</span><button onClick={check}>SUBMIT</button><button onClick={() => { setSeed(seed + 1); setAns(""); setRes(null); setShow(false); }}>NEW</button><button onClick={() => setShow(!showSteps)}>WORKED SOLUTION</button></div>
    {res !== null && <p className={res ? "ac-good" : "ac-bad"}>{res ? <><CheckCircle2 size={14} /> Correct within 2%.</> : <><XCircle size={14} /> Incorrect — expected ≈ {Number(q.answer.toPrecision(4))} {q.unit}.</>}</p>}
    {showSteps && <ol className="ac-steps">{q.steps.map(s => <li key={s}>{s}</li>)}</ol>}
  </div>;
}

export default function Academy({ onClose }: { onClose: () => void }) {
  const [active, setActive] = useState(0), [prog, setProg] = useState<Progress>({}), [myth, setMyth] = useState<boolean | null>(null);
  useEffect(() => setProg(loadProgress()), []);
  useEffect(() => setMyth(null), [active]);
  const save = (p: Progress) => { setProg(p); try { localStorage.setItem(KEY, JSON.stringify(p)); } catch {} };
  const mod = curriculum[active]!, Lab = LABS[mod.lab], mp = prog[mod.id] ?? { correct: 0 };
  const mastered = (id: string) => (prog[id]?.correct ?? 0) >= NEEDED && !!prog[id]?.myth;
  const total = curriculum.filter(m => mastered(m.id)).length;
  return <div className="panel-overlay"><div className="academy-panel">
    <header className="panel-header"><div><span className="eyebrow">MERIDIAN TRAINEE PROGRAMME / 100 LESSON PAGES</span><h2>ENGINEERING <em>ACADEMY</em></h2></div><div className="ac-total"><GraduationCap size={16} /> {total}/10 SECTORS MASTERED</div><button className="icon-button" onClick={onClose} aria-label="Close"><X /></button></header>
    <div className="ac-body">
      <nav className="ac-nav">{curriculum.map((m, i) => <button key={m.id} className={`${i === active ? "on" : ""} ${mastered(m.id) ? "done" : ""}`} onClick={() => setActive(i)}><span>{String(m.part).padStart(2, "0")}</span><div><b>{m.title}</b><small>{m.room} · {Math.min(prog[m.id]?.correct ?? 0, NEEDED)}/{NEEDED}{prog[m.id]?.myth ? " · ✓ myth" : ""}</small></div></button>)}</nav>
      <section className="ac-main">
        <div className="ac-head"><span className="eyebrow">PART {mod.part} · {mod.room}</span><h3>{mod.title}</h3><div className="ac-pages">{mod.pages.map((p, i) => <span key={p}>{String((mod.part - 1) * 10 + i + 1).padStart(3, "0")} {p}</span>)}</div></div>
        <div className="ac-grid">
          <article className="ac-card"><span className="eyebrow">LESSON</span>{mod.lesson.map(l => <p key={l}>{l}</p>)}<div className="ac-formulas">{mod.formulas.map(f => <code key={f}>{f}</code>)}</div>
            <div className="ac-myth"><span className="eyebrow">MISCONCEPTION CHECK</span><p>“{mod.myth.claim}”</p><div className="ac-tabs"><button onClick={() => { setMyth(true); if (mod.myth.truth) save({ ...prog, [mod.id]: { ...mp, myth: true } }); }}>TRUE</button><button onClick={() => { setMyth(false); if (!mod.myth.truth) save({ ...prog, [mod.id]: { ...mp, myth: true } }); }}>FALSE</button></div>{myth !== null && <p className={myth === mod.myth.truth ? "ac-good" : "ac-bad"}>{myth === mod.myth.truth ? "Correct. " : "Not quite. "}{mod.myth.why}</p>}</div>
          </article>
          <article className="ac-card"><span className="eyebrow">VIRTUAL LAB</span><Lab /></article>
        </div>
        <Assessment key={mod.id} mod={mod} onCorrect={() => save({ ...prog, [mod.id]: { ...mp, correct: mp.correct + 1 } })} />
        {mastered(mod.id) && <p className="ac-good ac-mastered">SECTOR {mod.room} MASTERED. The Engineer is watching.</p>}
      </section>
    </div>
  </div></div>;
}
