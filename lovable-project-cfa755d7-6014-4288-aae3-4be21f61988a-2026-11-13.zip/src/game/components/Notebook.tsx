import { BookOpen, FileText, Radio, Search, X } from "lucide-react";
import { useGameStore } from "../store/gameStore";
export default function Notebook({ onClose }: {onClose:()=>void}) {
  const { discoveries } = useGameStore();
  const found = discoveries.filter(d=>d.found);
  return <div className="panel-overlay"><div className="notebook-panel">
    <header className="panel-header"><div><span className="eyebrow">PERSONAL ARCHIVE / SUBJECT E-001</span><h2>ENGINEERING <em>NOTEBOOK</em></h2></div><button className="icon-button" onClick={onClose}><X/></button></header>
    <div className="notebook-content"><div className="notebook-count"><BookOpen/><strong>{found.length}</strong><span>DISCOVERIES RECOVERED</span></div>
      {found.length===0 ? <div className="empty-state"><Search/><b>NO EVIDENCE RECORDED</b><p>Investigate the room. Documents, clues and audio fragments will be stored here.</p></div> :
        found.map(d=><article className="evidence-card" key={d.id}><span>{d.category==="recording" ? <Radio size={14}/> : <FileText size={14}/>} {d.category.toUpperCase()} / {d.id}</span><h3>{d.title}</h3><p>{d.body}</p></article>)}
    </div>
  </div></div>;
}