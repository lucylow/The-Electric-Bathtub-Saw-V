import { useMemo, useState } from "react";
import { Activity, AlertTriangle, Calculator, CheckCircle2, Gauge, Lightbulb, RotateCcw, ShieldAlert, X } from "lucide-react";
import { calculateOhms } from "../engine/circuit";

type Scenario = "open" | "overload" | "low-voltage" | "power";
interface Props { onClose: () => void; }

const scenarios: { id: Scenario; title: string; brief: string; voltage: number; resistance: number; fuse: number; closed: boolean }[] = [
  { id: "open", title: "OPEN CONTACT", brief: "A broken switch contact interrupts the loop.", voltage: 12, resistance: 10, fuse: 2, closed: false },
  { id: "overload", title: "OVERCURRENT", brief: "The load resistance is too low for the protection rating.", voltage: 12, resistance: 3, fuse: 2, closed: true },
  { id: "low-voltage", title: "LOW SUPPLY", brief: "The source voltage has fallen below the indicator threshold.", voltage: 3, resistance: 10, fuse: 2, closed: true },
  { id: "power", title: "POWER BUDGET", brief: "Compare load power against the fictional 10 W component limit.", voltage: 12, resistance: 8, fuse: 3, closed: true },
];

export default function EngineeringWorkbench({ onClose }: Props) {
  const [scenario, setScenario] = useState<Scenario>("open");
  const active = scenarios.find(item => item.id === scenario)!;
  const [voltage, setVoltage] = useState(active.voltage);
  const [resistance, setResistance] = useState(active.resistance);
  const [fuse, setFuse] = useState(active.fuse);
  const [closed, setClosed] = useState(active.closed);
  const [measured, setMeasured] = useState(false);

  const loadScenario = (id: Scenario) => {
    const next = scenarios.find(item => item.id === id)!;
    setScenario(id); setVoltage(next.voltage); setResistance(next.resistance); setFuse(next.fuse); setClosed(next.closed); setMeasured(false);
  };
  const result = useMemo(() => {
    const { current, power } = calculateOhms(voltage, resistance);
    const state = !closed ? "OPEN LOOP" : current > fuse ? "PROTECTION TRIP" : power > 10 ? "POWER LIMIT EXCEEDED" : voltage < 5 ? "UNDERVOLTAGE" : "WITHIN MODEL LIMITS";
    const healthy = state === "WITHIN MODEL LIMITS";
    const detail = !closed
      ? "The switch contact is open. There is no continuous conducting path, so steady-state current is zero."
      : current > fuse
        ? `The calculated ${current.toFixed(2)} A exceeds the simulated ${fuse.toFixed(2)} A fuse rating. The protection model trips.`
        : power > 10
          ? `The load dissipates ${power.toFixed(2)} W, above the fictional 10 W component limit used in this exercise.`
          : voltage < 5
            ? "The source is below the 5 V training threshold. The circuit may be continuous, but the indicator cannot meet this model's operating requirement."
            : "The virtual loop is closed, current is below the fuse rating, and the load remains inside the training power limit.";
    return { current, power, state, healthy, detail };
  }, [voltage, resistance, fuse, closed]);

  return <div className="panel-overlay workbench-overlay" role="dialog" aria-modal="true" aria-labelledby="workbench-title">
    <section className="workbench-panel">
      <header className="panel-header"><div><span className="eyebrow">MERIDIAN INSTITUTE / ENGINEERING TRAINING</span><h2 id="workbench-title">FAULT <em>ANALYSIS WORKBENCH</em></h2></div><button className="icon-button" onClick={onClose} aria-label="Close workbench"><X/></button></header>
      <div className="workbench-warning"><ShieldAlert size={15}/><span>FICTIONAL LOW-VOLTAGE SOFTWARE MODEL ONLY. Not instructions for real electrical work.</span></div>
      <div className="workbench-layout">
        <aside className="scenario-list"><span className="workbench-label">SELECT A FAULT REPORT</span>{scenarios.map(item => <button key={item.id} className={`scenario-button ${scenario === item.id ? "selected" : ""}`} onClick={() => loadScenario(item.id)}><b>{item.title}</b><small>{item.brief}</small></button>)}</aside>
        <div className="workbench-main">
          <div className="workbench-intro"><div><span className="workbench-label">ACTIVE CASE / {scenario.toUpperCase()}</span><h3>{active.title}</h3><p>{active.brief}</p></div><Activity size={26}/></div>
          <div className="workbench-controls">
            <label><span>SUPPLY VOLTAGE <b>{voltage.toFixed(1)} V</b></span><input type="range" min="1" max="24" step="0.5" value={voltage} onChange={e => { setVoltage(Number(e.target.value)); setMeasured(false); }}/></label>
            <label><span>LOAD RESISTANCE <b>{resistance.toFixed(1)} Ω</b></span><input type="range" min="1" max="30" step="0.5" value={resistance} onChange={e => { setResistance(Number(e.target.value)); setMeasured(false); }}/></label>
            <label><span>FUSE RATING <b>{fuse.toFixed(1)} A</b></span><input type="range" min="0.25" max="8" step="0.25" value={fuse} onChange={e => { setFuse(Number(e.target.value)); setMeasured(false); }}/></label>
            <button className={`virtual-switch ${closed ? "on" : ""}`} onClick={() => { setClosed(v => !v); setMeasured(false); }}><span className="switch-light"/>{closed ? "VIRTUAL SWITCH: CLOSED" : "VIRTUAL SWITCH: OPEN"}</button>
          </div>
          <div className="workbench-meters"><div><Gauge/><span>CALCULATED CURRENT</span><b>{closed ? result.current.toFixed(2) : "0.00"} <small>A</small></b></div><div><Lightbulb/><span>LOAD POWER</span><b>{closed ? result.power.toFixed(2) : "0.00"} <small>W</small></b></div><div><Calculator/><span>TOTAL RESISTANCE</span><b>{resistance.toFixed(2)} <small>Ω</small></b></div></div>
          <div className={`workbench-diagnosis ${measured ? (result.healthy ? "healthy" : "fault") : "pending"}`}><div className="diagnosis-heading">{measured && result.healthy ? <CheckCircle2/> : <AlertTriangle/>}<b>{measured ? result.state : "AWAITING DIAGNOSTIC RUN"}</b></div><p>{measured ? result.detail : "Adjust the virtual components, predict the outcome, then run the diagnostic to reveal the model's result."}</p></div>
          <div className="workbench-actions"><button className="run-button" onClick={() => setMeasured(true)}><Activity size={16}/> RUN FAULT DIAGNOSTIC</button><button className="hint-button" onClick={() => loadScenario(scenario)}><RotateCcw size={14}/> RESET CASE</button></div>
          <p className="workbench-formula">MODEL: I = V / R&nbsp;&nbsp; · &nbsp;&nbsp;P = V × I&nbsp;&nbsp; · &nbsp;&nbsp;Fuse trip when I exceeds rating</p>
        </div>
      </div>
    </section>
  </div>;
}
