import { useMemo, useState } from "react";
import { Activity, BookOpen, Boxes, Database, FileText, Medal, Search, ShieldAlert, X } from "lucide-react";
import {
  mockComponents, mockDatasetSummary, mockEvents, mockEvidence, mockLearners,
  mockMissions, generateMockScenario
} from "../data/mock";

type Tab = "overview" | "missions" | "parts" | "evidence" | "activity" | "cohort";

export default function MockDataLab({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>("overview");
  const [query, setQuery] = useState("");
  const [seed, setSeed] = useState(20261112);
  const generated = useMemo(() => generateMockScenario(seed), [seed]);
  const filter = (value: unknown) => JSON.stringify(value).toLowerCase().includes(query.toLowerCase());
  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "overview", label: "OVERVIEW", icon: <Database size={14}/> },
    { id: "missions", label: "MISSIONS", icon: <ShieldAlert size={14}/> },
    { id: "parts", label: "COMPONENTS", icon: <Boxes size={14}/> },
    { id: "evidence", label: "EVIDENCE", icon: <FileText size={14}/> },
    { id: "activity", label: "EVENT STREAM", icon: <Activity size={14}/> },
    { id: "cohort", label: "LEADERBOARD", icon: <Medal size={14}/> },
  ];
  const exportJson = (name: string, data: unknown) => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `${name}.json`; a.click();
    URL.revokeObjectURL(url);
  };
  return <div className="panel-overlay mockdata-overlay" role="dialog" aria-modal="true" aria-labelledby="mockdata-title">
    <section className="mockdata-panel">
      <header className="mockdata-header">
        <div><span className="workbench-label"><Database size={13}/> MERIDIAN INSTITUTE / DATA ARCHIVE</span>
          <h2 id="mockdata-title">MOCK DATA CONTROL ROOM</h2>
          <p>Explore populated demo records, inspect fictional scenarios, and export datasets.</p></div>
        <button className="icon-button" onClick={onClose} aria-label="Close mock data lab"><X/></button>
      </header>
      <div className="mockdata-warning">DEMO DATA ONLY · NO REAL TRAINEES · NO REAL FACILITY TELEMETRY · VIRTUAL DC MODELS</div>
      <nav className="mockdata-tabs">{tabs.map(t => <button key={t.id} className={tab===t.id?"active":""} onClick={()=>{setTab(t.id);setQuery("");}}>{t.icon}{t.label}</button>)}</nav>
      {tab !== "overview" && <label className="mockdata-search"><Search size={15}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search this dataset..." /></label>}
      <div className="mockdata-content">
        {tab === "overview" && <>
          <div className="mockdata-stat-grid">
            {Object.entries({MISSIONS:mockDatasetSummary.missions, COMPONENTS:mockDatasetSummary.components, EVIDENCE:mockDatasetSummary.evidence, TRAINEES:mockDatasetSummary.learners, EVENTS:mockDatasetSummary.events}).map(([k,v])=><div className="mockdata-stat" key={k}><small>{k}</small><b>{v.toString().padStart(2,"0")}</b></div>)}
          </div>
          <div className="mockdata-card"><h3>SEEDED SCENARIO GENERATOR</h3><p>Generate repeatable fictional circuit drills. Reusing a seed produces the same scenario.</p>
            <div className="mockdata-generator"><label>SEED<input type="number" value={seed} onChange={e=>setSeed(Number(e.target.value)||1)}/></label><button onClick={()=>setSeed(v=>v+1)}>NEW SEED ↻</button></div>
            <div className="generated-preview"><b>{generated.id} / {generated.title}</b><span>{generated.difficulty} PRIORITY · {generated.concept}</span><p>{generated.clue}</p><small>MODEL: {generated.sourceVoltageV} V / {generated.nominalResistanceOhm} Ω / {generated.expectedCurrentA} A</small></div>
            <button className="mockdata-export" onClick={()=>exportJson("generated-training-scenario",generated)}>EXPORT GENERATED SCENARIO JSON</button>
          </div>
          <div className="mockdata-card"><h3>DATASET CONTRACT</h3><p>All records are synthetic, local, and designed for interface testing. They do not describe real people, electrical installations, or facility operations.</p><button className="mockdata-export" onClick={()=>exportJson("electric-bathtub-demo-dataset",{mockMissions,mockComponents,mockEvidence,mockLearners,mockEvents})}>EXPORT COMPLETE DATASET JSON</button></div>
        </>}
        {tab === "missions" && <div className="mockdata-records">{mockMissions.filter(filter).map(m=><article key={m.id}><div><b>{m.id} · {m.title}</b><span>{m.difficulty} / CHAPTER {m.chapter}</span></div><p>{m.scene}</p><small>{m.concept} · {m.sourceVoltageV} V · {m.nominalResistanceOhm} Ω · {m.expectedCurrentA} A · {m.points} PTS</small></article>)}</div>}
        {tab === "parts" && <div className="mockdata-records">{mockComponents.filter(filter).map(c=><article key={c.id}><div><b>{c.id} · {c.label}</b><span>{c.condition.toUpperCase()}</span></div><p>{c.kind.toUpperCase()} · {c.value} {c.unit} · ±{c.tolerancePercent}% tolerance</p><small>DEMO STOCK: {c.stock} · TRAINING MODEL ONLY</small></article>)}</div>}
        {tab === "evidence" && <div className="mockdata-records">{mockEvidence.filter(filter).map(e=><article key={e.id}><div><b>{e.id} · {e.title}</b><span>{e.type.toUpperCase()}</span></div><p>{e.content}</p><small>{e.room} · {e.timestamp} · UNLOCKED BY {e.unlockedBy}</small></article>)}</div>}
        {tab === "activity" && <div className="mockdata-records">{mockEvents.filter(filter).slice().reverse().map(e=><article key={e.id}><div><b>{e.id} · {e.type}</b><span>{e.at}</span></div><p>{e.message}</p><small>{e.missionId} · {e.actor} · {e.level.toUpperCase()}</small></article>)}</div>}
        {tab === "cohort" && <div className="mockdata-records">{mockLearners.filter(filter).slice().sort((a,b)=>a.rank-b.rank).map(l=><article key={l.id}><div><b>#{l.rank} · {l.displayName}</b><span>{l.score.toLocaleString()} PTS</span></div><p>{l.cohort} · {l.missionsCompleted} missions · {l.accuracyPercent}% accuracy</p><small>{l.streakDays} day streak · FICTIONAL DEMO PROFILE</small></article>)}</div>}
      </div>
      <footer className="mockdata-footer"><span>DATASET BUILD 1.3 / {mockDatasetSummary.label}</span><button onClick={onClose}>CLOSE ARCHIVE</button></footer>
    </section>
  </div>;
}
