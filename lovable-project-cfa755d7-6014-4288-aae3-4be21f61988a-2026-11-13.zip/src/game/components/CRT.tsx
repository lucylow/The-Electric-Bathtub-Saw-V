import { useEffect, useState } from "react";
import { Radio, Power } from "lucide-react";
interface Props { line: string; active?: boolean; onPower?: () => void; }
export default function CRT({ line, active = true, onPower }: Props) {
  const [typed, setTyped] = useState("");
  useEffect(() => {
    setTyped("");
    if (!active) return;
    let i = 0;
    const timer = window.setInterval(() => {
      i++;
      setTyped(line.slice(0, i));
      if (i >= line.length) window.clearInterval(timer);
    }, 28);
    return () => window.clearInterval(timer);
  }, [line, active]);
  return <div className={`crt ${active ? "crt-on" : "crt-off"}`}>
    <div className="crt-top"><span><Radio size={12}/> MERIDIAN INSTITUTE // BROADCAST 01</span><button onClick={onPower} aria-label="Toggle CRT"><Power size={14}/></button></div>
    <div className="crt-screen"><div className="scanlines"/><div className="crt-stamp">E-001</div>
      {active ? <><p className="crt-label">THE ENGINEER</p><p className="crt-message">{typed}<span className="cursor">_</span></p></> : <div className="no-signal">NO SIGNAL</div>}
    </div>
    <div className="crt-bottom"><span>CH 05</span><span>REC <i className="rec-dot"/></span><span>MONO</span></div>
  </div>;
}