import { useMemo, useState } from "react";
import { ArrowRight, BatteryCharging, CheckCircle2, CircleHelp, Gauge, Lightbulb, Power, RotateCcw, X } from "lucide-react";
import { initialCircuit } from "../data/puzzles";
import { solveLoop } from "../engine/circuit";
import { useGameStore } from "../store/gameStore";
import type { CircuitComponent } from "../types";

interface Props { onClose: () => void; }
export default function CircuitPanel({ onClose }: Props) {
  const [parts, setParts] = useState<CircuitComponent[]>(initialCircuit);
  const [ran, setRan] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const { unlock, unlockedLocks, attempt, useHint, setMessage } = useGameStore();
  const result = useMemo(() => solveLoop(parts), [parts]);
  const switchPart = parts.find(p=>p.kind==="switch")!;
  const updateSwitch = () => {
    setParts(old => old.map(p => p.kind==="switch" ? {...p, closed: !p.closed} : p));
    setRan(false);
  };
  const run = () => {
    attempt(); setRan(true);
    if (result.complete) { unlock(0); setMessage("VIRTUAL LOCK 01 RELEASED"); }
    else setMessage(result.message);
  };
  const reset = () => { setParts(initialCircuit); setRan(false); setShowHint(false); };
  return <div className="panel-overlay">
    <div className="circuit-panel">
      <header className="panel-header"><div><span className="eyebrow">MERIDIAN INSTITUTE / DIAGNOSTIC TERMINAL</span><h2>EXPERIMENT 001 <em>— THE FIRST CONNECTION</em></h2></div><button className="icon-button" onClick={onClose}><X/></button></header>
      <div className="panel-meta"><span>VIRTUAL DC SYSTEM / 12.0 V</span><span className="safe-tag">ISOLATED SOFTWARE SIMULATION</span></div>
      <div className="panel-body">
        <div className="schematic-area">
          <div className="schematic-heading"><span>FIG 01-A / INCOMPLETE LOOP</span><span>NOT TO SCALE</span></div>
          <div className="circuit-visual">
            <div className="wire wire-top"/><div className="wire wire-right"/><div className="wire wire-bottom"/><div className="wire wire-left"/>
            <div className="source-symbol"><BatteryCharging/><b>12V</b><small>DC SOURCE</small></div>
            <button className={`switch-symbol ${switchPart.closed ? "switch-closed" : ""}`} onClick={updateSwitch}><span className="switch-track"/><span className="switch-lever"/><b>SW-01</b><small>{switchPart.closed ? "CLOSED" : "OPEN"}</small></button>
            <div className="resistor-symbol"><span>／\/\/</span><b>R1 · 8Ω</b></div>
            <div className="lamp-symbol"><Lightbulb/><b>L1 · 2Ω</b></div>
            <div className={`node node-a ${switchPart.closed ? "lit" : ""}`}/><div className="node node-b"/><div className="node node-c"/>
            <div className="path-label">RETURN PATH</div>
          </div>
          <div className="component-strip">
            <div><BatteryCharging/><span>DC SOURCE</span><b>12.0 V</b></div><div><Gauge/><span>LOAD RESISTOR</span><b>8.0 Ω</b></div><div><Lightbulb/><span>INDICATOR</span><b>2.0 Ω</b></div>
          </div>
          <div className="switch-control"><div><b>SWITCH SW-01</b><small>Toggle the virtual contact to complete the loop.</small></div><button className={switchPart.closed ? "toggle active" : "toggle"} onClick={updateSwitch}><span/>{switchPart.closed ? "CLOSED" : "OPEN"}</button></div>
        </div>
        <aside className="diagnostic-side">
          <div className="side-title">LIVE DIAGNOSTICS <i className={ran && result.complete ? "status-green" : "status-red"}/></div>
          <div className="meter-readout"><span>SUPPLY VOLTAGE</span><strong>12.00 <small>V</small></strong></div>
          <div className="meter-readout"><span>LOOP RESISTANCE</span><strong>{ran && Number.isFinite(result.resistance) ? result.resistance.toFixed(2) : "—"} <small>Ω</small></strong></div>
          <div className="meter-readout"><span>CALCULATED CURRENT</span><strong>{ran ? result.current.toFixed(2) : "—"} <small>A</small></strong></div>
          <div className="meter-readout"><span>LOAD POWER</span><strong>{ran ? result.power.toFixed(2) : "—"} <small>W</small></strong></div>
          <div className={`diagnostic-result ${ran && result.complete ? "success" : ""}`}><b>{ran ? result.message : "AWAITING MEASUREMENT"}</b><p>{ran ? result.explanation : "Configure the virtual circuit, then run diagnostics. No physical equipment is connected."}</p></div>
          <button className="run-button" onClick={run}><Power size={16}/> RUN SIMULATION <ArrowRight size={16}/></button>
          <button className="hint-button" onClick={()=>{setShowHint(v=>!v);useHint();}}><CircleHelp size={15}/> REQUEST ENGINEERING HINT</button>
          {showHint && <div className="hint-box">A circuit needs a complete conducting path from the source and back again. Inspect the switch symbol: is the contact physically closed in the diagram?</div>}
        </aside>
      </div>
      <footer className="panel-footer"><span>TRAINING MODEL // DC STEADY STATE</span><button onClick={reset}><RotateCcw size={13}/> RESET CIRCUIT</button><button onClick={onClose}>CLOSE TERMINAL <X size={13}/></button></footer>
    </div>
  </div>;
}