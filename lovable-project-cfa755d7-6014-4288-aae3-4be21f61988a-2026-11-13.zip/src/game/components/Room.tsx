import { useState } from "react";
import { Search, FileText, DoorClosed, Waves, PanelTop, LockKeyhole } from "lucide-react";
import CRT from "./CRT";
import { useGameStore } from "../store/gameStore";
import { engineerLines } from "../data/story";

interface Props { onOpenCircuit: () => void; }
export default function Room({ onOpenCircuit }: Props) {
  const [crtOn, setCrtOn] = useState(true);
  const [inspected, setInspected] = useState<string | null>(null);
  const { unlockedLocks, discover, discoveries, setMessage } = useGameStore();
  const inspect = (id: string, label: string) => {
    setInspected(label);
    if (id) discover(id);
    setMessage(`INSPECTING: ${label}`);
  };
  return <section className="room-scene">
    <div className="room-grid"/>
    <div className="room-vignette"/>
    <div className="room-topline"><span>MERIDIAN INSTITUTE / SUBLEVEL -03</span><span>EXPERIMENT 001 / LIVE FEED</span></div>
    <div className="room-ceiling"><span>⚠ AUXILIARY POWER ONLY</span><span>CAM 04 // SIGNAL DEGRADED</span></div>
    <div className="room-backwall">
      <div className="pipe pipe-a"/><div className="pipe pipe-b"/>
      <div className="warning-sign">DANGER<br/><small>AUTHORIZED PERSONNEL ONLY</small></div>
      <div className="lock-wall">
        {Array.from({length:5}, (_,i) => <button key={i} className={`lock-unit ${unlockedLocks.includes(i) ? "released" : ""}`} onClick={() => inspect("", `LOCK ${i+1} — ${unlockedLocks.includes(i) ? "RELEASED" : "MAGNETIC LATCH"}`)}>
          <span className="lock-number">0{i+1}</span><LockKeyhole size={22}/><span className="lock-state">{unlockedLocks.includes(i) ? "OPEN" : "SEALED"}</span><i/>
        </button>)}
      </div>
      <div className="door-frame"><div className="door"><div className="door-window"/><span>EXIT / AUTHORIZED RELEASE</span><div className="door-handle"/></div></div>
    </div>
    <div className="room-floor"/>
    <div className="bathtub" onClick={() => inspect("photo-02", "CENTRAL BATHTUB PROP")} onKeyDown={e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();inspect("photo-02", "CENTRAL BATHTUB PROP");}}} role="button" tabIndex={0} aria-label="Inspect central bathtub prop">
      <div className="tub-rim"/><div className="tub-water"><Waves size={30}/><span>INERT DISPLAY PROP</span></div><div className="tub-leg leg-one"/><div className="tub-leg leg-two"/>
    </div>
    <div className="desk" onClick={() => inspect("note-01", "MAINTENANCE DESK")} onKeyDown={e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();inspect("note-01", "MAINTENANCE DESK");}}} role="button" tabIndex={0} aria-label="Inspect maintenance desk">
      <div className="desk-top"/><div className="paper"><FileText size={17}/><span>FIELD<br/>NOTES</span></div><div className="desk-leg"/>
    </div>
    <div className="crt-position"><CRT line={engineerLines.intro} active={crtOn} onPower={() => setCrtOn(v=>!v)}/></div>
    <button className="control-console" onClick={onOpenCircuit}><PanelTop size={20}/><span>CONTROL<br/>CONSOLE</span><b>INTERACT [E]</b></button>
    <button className="inspect-hotspot hotspot-note" onClick={() => inspect("diagram-01","HAND-DRAWN SCHEMATIC")}><Search size={14}/> SCHEMATIC</button>
    <button className="inspect-hotspot hotspot-cabinet" onClick={() => inspect("log-01","RECOVERED AUDIO LOG")}><Search size={14}/> AUDIO LOG</button>
    <div className="room-interaction-hint">{inspected ? <><b>{inspected}</b><span>{inspected.startsWith("LOCK")?"Locks release when you solve circuits at the control console.":"Evidence added to your notebook (press N)."}</span></> : <><b>INVESTIGATE THE ROOM</b><span>Select objects to inspect · Open the control console to begin</span></>}</div>
    <div className="room-footer"><span>OBJECTS FOUND {discoveries.filter(d=>d.found).length}/10</span><span>ENVIRONMENTAL SYSTEMS: NOMINAL</span></div>
  </section>;
}