import { Volume2, Eye, Clock3, RotateCcw, X } from "lucide-react";
import { useState } from "react";
import { useGameStore } from "../store/gameStore";
import type { Difficulty } from "../types";
export default function Settings({onClose}:{onClose:()=>void}) {
  const {difficulty,setDifficulty,reset,reducedMotion,setReducedMotion}=useGameStore();
  const [subtitles,setSubtitles]=useState(true);
  return <div className="panel-overlay"><div className="settings-panel">
    <header className="panel-header"><div><span className="eyebrow">SUBJECT CONFIGURATION</span><h2>EXPERIMENT <em>SETTINGS</em></h2></div><button className="icon-button" onClick={onClose}><X/></button></header>
    <section className="setting-group"><h3>DIFFICULTY PROFILE</h3>{(["story","engineering","nightmare"] as Difficulty[]).map(d=><button key={d} className={`difficulty-option ${difficulty===d?"selected":""}`} onClick={()=>setDifficulty(d)}><b>{d.toUpperCase()}</b><span>{d==="story"?"Guided explanations · No countdown pressure":d==="engineering"?"Real calculations · Limited hints":"Timed challenges · Hidden diagnostic faults"}</span></button>)}</section>
    <section className="setting-group"><h3>ACCESSIBILITY</h3><label><span><Eye/> Reduced camera motion</span><input type="checkbox" checked={reducedMotion} onChange={e=>setReducedMotion(e.target.checked)}/></label><label><span><Volume2/> Subtitles</span><input type="checkbox" checked={subtitles} onChange={e=>setSubtitles(e.target.checked)}/></label><label><span><Clock3/> Untimed exploration</span><input type="checkbox" defaultChecked/></label></section>
    <button className="danger-button" onClick={()=>{if(confirm("Erase this experiment save and restart?"))reset();}}> <RotateCcw size={15}/> RESET EXPERIMENT</button>
  </div></div>;
}