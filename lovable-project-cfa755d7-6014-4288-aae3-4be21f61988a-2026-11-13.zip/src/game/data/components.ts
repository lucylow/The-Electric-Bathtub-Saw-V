export const componentLibrary = [
  { kind:"source", name:"DC source", symbol:"⎓", unit:"V", lesson:"A voltage source establishes electric potential difference in the virtual network." },
  { kind:"resistor", name:"Resistor", symbol:"／\/\/", unit:"Ω", lesson:"Resistance relates voltage and current in an ohmic model." },
  { kind:"switch", name:"Switch", symbol:"o/ o", unit:"state", lesson:"A closed switch provides continuity; an open switch interrupts the ideal path." },
  { kind:"lamp", name:"Indicator load", symbol:"⊗", unit:"Ω", lesson:"The indicator is a fictional resistive load used to visualize current." },
  { kind:"fuse", name:"Virtual fuse", symbol:"—[ ]—", unit:"A", lesson:"The virtual protective element demonstrates a rating check. Never bypass protection." },
  { kind:"relay", name:"Relay", symbol:"—(coil)—", unit:"state", lesson:"A coil creates a magnetic field that operates electrically isolated contacts in the model." }
] as const;