import type { CircuitComponent } from "../types";
export const initialCircuit: CircuitComponent[] = [
  { id: "battery", kind: "source", label: "VIRTUAL DC SOURCE", value: 12, unit: "V", from: "A", to: "B" },
  { id: "switch", kind: "switch", label: "TOGGLE SWITCH", value: 0, unit: "state", from: "B", to: "C", closed: false },
  { id: "resistor", kind: "resistor", label: "LOAD RESISTOR", value: 8, unit: "Ω", from: "C", to: "D" },
  { id: "lamp", kind: "lamp", label: "INDICATOR LOAD", value: 2, unit: "Ω", from: "D", to: "E" },
  { id: "fuse", kind: "fuse", label: "VIRTUAL FUSE RATING", value: 2, unit: "A", from: "E", to: "A" }
];
export const lockLessons = [
  { title: "THE FIRST CONNECTION", concept: "Continuity & open circuits", objective: "Close the virtual switch and restore a complete loop." },
  { title: "THE RESISTANCE ROOM", concept: "Ohm's law", objective: "Predict how resistance changes current in a virtual circuit." },
  { title: "THE FIVE PATHS", concept: "Series & parallel networks", objective: "Compare branch currents and total resistance." },
  { title: "THE MAGNETIC DOOR", concept: "Relays & electromagnetism", objective: "Identify the coil, control input and switched contact." },
  { title: "THE MASTER CIRCUIT", concept: "Fault diagnosis", objective: "Use measurements to isolate a hidden virtual fault." }
];