export const hintBank: Record<string, string[]> = {
  continuity: [
    "A circuit needs a complete path from one terminal of the source back to the other.",
    "Look for the component that is drawn with a visible gap between its contacts.",
    "Toggle the virtual switch to its closed state, then run the diagnostic."
  ],
  ohmsLaw: [
    "Use I = V / R for the simplified resistive DC load.",
    "Total series resistance is the sum of the individual resistances.",
    "Compare your predicted current with the meter readout."
  ],
  parallel: [
    "Parallel branches share the same node-to-node voltage.",
    "Use Kirchhoff's current law to compare the current entering and leaving a node.",
    "Check each branch independently before calculating the total."
  ],
  relay: [
    "A relay has a control coil and a separate set of contacts.",
    "The coil state changes the contact state in this virtual model.",
    "Do not confuse the control circuit with the switched circuit."
  ],
  diagnosis: [
    "A measurement is evidence; a guess is only a hypothesis.",
    "Compare expected and observed values at more than one node.",
    "Change one variable at a time and record the result."
  ]
};