import { describe, expect, it } from "vitest";
import { mockComponents, mockEvidence, mockLearners, mockMissions, generateMockScenario } from "./index";

describe("mock training dataset", () => {
  it("generates the same scenario for the same seed", () => {
    expect(generateMockScenario(12345)).toEqual(generateMockScenario(12345));
  });
  it("generates different scenarios for different seeds", () => {
    expect(generateMockScenario(12345).id).not.toEqual(generateMockScenario(54321).id);
  });
  it("uses unique mission identifiers", () => {
    expect(new Set(mockMissions.map(x => x.id)).size).toBe(mockMissions.length);
  });
  it("keeps all evidence unlock references valid", () => {
    const ids = new Set(mockMissions.map(x => x.id));
    expect(mockEvidence.every(x => ids.has(x.unlockedBy))).toBe(true);
  });
  it("marks all trainee profiles as fictional demo records", () => {
    expect(mockLearners.every(x => x.isFictionalDemoData)).toBe(true);
  });
  it("keeps all component stock counts non-negative", () => {
    expect(mockComponents.every(x => x.stock >= 0)).toBe(true);
  });
});
