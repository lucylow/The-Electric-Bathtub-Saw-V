export * from "./types";
export { mockMissions } from "./missions";
export { mockComponents } from "./components";
export { mockEvidence } from "./evidence";
export { mockLearners } from "./learners";
export { mockEvents } from "./events";
export { generateMockScenario } from "./scenarioGenerator";

import { mockMissions } from "./missions";
import { mockComponents } from "./components";
import { mockEvidence } from "./evidence";
import { mockLearners } from "./learners";
import { mockEvents } from "./events";

export const mockDatasetSummary = {
  missions: mockMissions.length,
  components: mockComponents.length,
  evidence: mockEvidence.length,
  learners: mockLearners.length,
  events: mockEvents.length,
  label: "FICTIONAL LOCAL DEMO DATA",
  warning: "All values represent virtual classroom scenarios, not real equipment or operational telemetry."
};

export function getMockMission(id: string) {
  return mockMissions.find((mission) => mission.id === id);
}
