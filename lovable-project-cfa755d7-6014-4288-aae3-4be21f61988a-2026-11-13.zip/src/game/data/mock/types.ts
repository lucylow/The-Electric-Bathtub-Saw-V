export type MockSeverity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
export interface MockMission {
  id: string; title: string; chapter: number; difficulty: MockSeverity; concept: string;
  faultType: string; scene: string; sourceVoltageV: number; nominalResistanceOhm: number;
  expectedCurrentA: number; timeLimitSeconds: number; points: number; tags: string[];
  trainingOnly: boolean;
}
export interface MockComponent {
  id: string; kind: string; label: string; value: number; unit: string;
  tolerancePercent: number; stock: number; condition: "new" | "tested" | "aged";
  trainingModel: boolean;
}
export interface MockEvidence {
  id: string; title: string; type: string; room: string; timestamp: string;
  content: string; unlockedBy: string; trainingOnly: boolean;
}
export interface MockLearner {
  id: string; displayName: string; cohort: string; rank: number; score: number;
  missionsCompleted: number; accuracyPercent: number; streakDays: number;
  badgeIds: string[]; isFictionalDemoData: boolean;
}
export interface MockEvent {
  id: string; sequence: number; at: string; type: string; message: string;
  level: "info" | "success" | "warning"; missionId: string; actor: string; source: string;
}
