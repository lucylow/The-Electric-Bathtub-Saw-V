import type { MockLearner } from "./types";

export const mockLearners: MockLearner[] = [
  {
    "id": "TRAINEE-001",
    "displayName": "Avery Chen",
    "cohort": "DAY SHIFT",
    "rank": 1,
    "score": 1426,
    "missionsCompleted": 11,
    "accuracyPercent": 68,
    "streakDays": 1,
    "badgeIds": [
      "first-loop"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-002",
    "displayName": "Jordan Patel",
    "cohort": "WEEKEND LAB",
    "rank": 2,
    "score": 1372,
    "missionsCompleted": 10,
    "accuracyPercent": 75,
    "streakDays": 2,
    "badgeIds": [
      "first-loop",
      "fault-finder"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-003",
    "displayName": "Morgan Ellis",
    "cohort": "NIGHT SHIFT",
    "rank": 3,
    "score": 1318,
    "missionsCompleted": 9,
    "accuracyPercent": 82,
    "streakDays": 3,
    "badgeIds": [
      "first-loop"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-004",
    "displayName": "Sam Rivera",
    "cohort": "DAY SHIFT",
    "rank": 4,
    "score": 1188,
    "missionsCompleted": 8,
    "accuracyPercent": 89,
    "streakDays": 4,
    "badgeIds": [
      "first-loop",
      "fault-finder"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-005",
    "displayName": "Taylor Brooks",
    "cohort": "WEEKEND LAB",
    "rank": 5,
    "score": 1134,
    "missionsCompleted": 7,
    "accuracyPercent": 96,
    "streakDays": 5,
    "badgeIds": [
      "first-loop"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-006",
    "displayName": "Riley Okafor",
    "cohort": "NIGHT SHIFT",
    "rank": 6,
    "score": 1080,
    "missionsCompleted": 6,
    "accuracyPercent": 65,
    "streakDays": 0,
    "badgeIds": [
      "first-loop",
      "fault-finder"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-007",
    "displayName": "Casey Nguyen",
    "cohort": "DAY SHIFT",
    "rank": 7,
    "score": 1026,
    "missionsCompleted": 5,
    "accuracyPercent": 72,
    "streakDays": 1,
    "badgeIds": [
      "first-loop"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-008",
    "displayName": "Jamie Wilson",
    "cohort": "WEEKEND LAB",
    "rank": 8,
    "score": 896,
    "missionsCompleted": 12,
    "accuracyPercent": 79,
    "streakDays": 2,
    "badgeIds": [
      "first-loop",
      "fault-finder"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-009",
    "displayName": "Alex Morgan",
    "cohort": "NIGHT SHIFT",
    "rank": 9,
    "score": 842,
    "missionsCompleted": 11,
    "accuracyPercent": 86,
    "streakDays": 3,
    "badgeIds": [
      "first-loop"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-010",
    "displayName": "Drew Singh",
    "cohort": "DAY SHIFT",
    "rank": 10,
    "score": 788,
    "missionsCompleted": 10,
    "accuracyPercent": 93,
    "streakDays": 4,
    "badgeIds": [
      "first-loop",
      "fault-finder"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-011",
    "displayName": "Quinn Foster",
    "cohort": "WEEKEND LAB",
    "rank": 11,
    "score": 734,
    "missionsCompleted": 9,
    "accuracyPercent": 62,
    "streakDays": 5,
    "badgeIds": [
      "first-loop"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-012",
    "displayName": "Cameron Li",
    "cohort": "NIGHT SHIFT",
    "rank": 12,
    "score": 604,
    "missionsCompleted": 8,
    "accuracyPercent": 69,
    "streakDays": 0,
    "badgeIds": [
      "first-loop",
      "fault-finder"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-013",
    "displayName": "Skylar Ahmed",
    "cohort": "DAY SHIFT",
    "rank": 13,
    "score": 550,
    "missionsCompleted": 7,
    "accuracyPercent": 76,
    "streakDays": 1,
    "badgeIds": [
      "first-loop"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-014",
    "displayName": "Reese Martin",
    "cohort": "WEEKEND LAB",
    "rank": 14,
    "score": 496,
    "missionsCompleted": 6,
    "accuracyPercent": 83,
    "streakDays": 2,
    "badgeIds": [
      "first-loop",
      "fault-finder"
    ],
    "isFictionalDemoData": true
  },
  {
    "id": "TRAINEE-015",
    "displayName": "Rowan Clarke",
    "cohort": "NIGHT SHIFT",
    "rank": 15,
    "score": 442,
    "missionsCompleted": 5,
    "accuracyPercent": 90,
    "streakDays": 3,
    "badgeIds": [
      "first-loop"
    ],
    "isFictionalDemoData": true
  }
];
