import type { MockEvidence } from "./types";

export const mockEvidence: MockEvidence[] = [
  {
    "id": "EVD-001",
    "title": "Maintenance ticket #01",
    "type": "recording",
    "room": "Sector A",
    "timestamp": "02:07:13",
    "content": "The instructor reminds trainees to compare a measurement with a stated reference.",
    "unlockedBy": "SIM-001",
    "trainingOnly": true
  },
  {
    "id": "EVD-002",
    "title": "Technician audio transcript #02",
    "type": "schematic",
    "room": "Sector A",
    "timestamp": "02:14:26",
    "content": "The drawing shows two branches connected across the same ideal source nodes.",
    "unlockedBy": "SIM-002",
    "trainingOnly": true
  },
  {
    "id": "EVD-003",
    "title": "Schematic fragment #03",
    "type": "measurement",
    "room": "Sector A",
    "timestamp": "02:21:39",
    "content": "The meter's classroom calibration offset is documented as a simulated value.",
    "unlockedBy": "SIM-003",
    "trainingOnly": true
  },
  {
    "id": "EVD-004",
    "title": "Meter calibration card #04",
    "type": "document",
    "room": "Sector A",
    "timestamp": "02:28:52",
    "content": "Do not change multiple variables at once; preserve a clear diagnostic trail.",
    "unlockedBy": "SIM-004",
    "trainingOnly": true
  },
  {
    "id": "EVD-005",
    "title": "Shift handover note #05",
    "type": "recording",
    "room": "Sector A",
    "timestamp": "02:35:05",
    "content": "The virtual branch was reported open during the previous training cycle.",
    "unlockedBy": "SIM-005",
    "trainingOnly": true
  },
  {
    "id": "EVD-006",
    "title": "Component inspection #06",
    "type": "schematic",
    "room": "Sector B",
    "timestamp": "02:42:18",
    "content": "The instructor reminds trainees to compare a measurement with a stated reference.",
    "unlockedBy": "SIM-006",
    "trainingOnly": true
  },
  {
    "id": "EVD-007",
    "title": "Control-room memo #07",
    "type": "measurement",
    "room": "Sector B",
    "timestamp": "02:49:31",
    "content": "The drawing shows two branches connected across the same ideal source nodes.",
    "unlockedBy": "SIM-007",
    "trainingOnly": true
  },
  {
    "id": "EVD-008",
    "title": "Training worksheet #08",
    "type": "document",
    "room": "Sector B",
    "timestamp": "02:56:44",
    "content": "The meter's classroom calibration offset is documented as a simulated value.",
    "unlockedBy": "SIM-008",
    "trainingOnly": true
  },
  {
    "id": "EVD-009",
    "title": "Incident photograph description #09",
    "type": "recording",
    "room": "Sector B",
    "timestamp": "02:03:57",
    "content": "Do not change multiple variables at once; preserve a clear diagnostic trail.",
    "unlockedBy": "SIM-009",
    "trainingOnly": true
  },
  {
    "id": "EVD-010",
    "title": "Relay timing log #10",
    "type": "schematic",
    "room": "Sector B",
    "timestamp": "02:10:10",
    "content": "The virtual branch was reported open during the previous training cycle.",
    "unlockedBy": "SIM-010",
    "trainingOnly": true
  },
  {
    "id": "EVD-011",
    "title": "Maintenance ticket #11",
    "type": "measurement",
    "room": "Sector C",
    "timestamp": "02:17:23",
    "content": "The instructor reminds trainees to compare a measurement with a stated reference.",
    "unlockedBy": "SIM-011",
    "trainingOnly": true
  },
  {
    "id": "EVD-012",
    "title": "Technician audio transcript #12",
    "type": "document",
    "room": "Sector C",
    "timestamp": "02:24:36",
    "content": "The drawing shows two branches connected across the same ideal source nodes.",
    "unlockedBy": "SIM-012",
    "trainingOnly": true
  },
  {
    "id": "EVD-013",
    "title": "Schematic fragment #13",
    "type": "recording",
    "room": "Sector C",
    "timestamp": "02:31:49",
    "content": "The meter's classroom calibration offset is documented as a simulated value.",
    "unlockedBy": "SIM-001",
    "trainingOnly": true
  },
  {
    "id": "EVD-014",
    "title": "Meter calibration card #14",
    "type": "schematic",
    "room": "Sector C",
    "timestamp": "02:38:02",
    "content": "Do not change multiple variables at once; preserve a clear diagnostic trail.",
    "unlockedBy": "SIM-002",
    "trainingOnly": true
  },
  {
    "id": "EVD-015",
    "title": "Shift handover note #15",
    "type": "measurement",
    "room": "Sector C",
    "timestamp": "02:45:15",
    "content": "The virtual branch was reported open during the previous training cycle.",
    "unlockedBy": "SIM-003",
    "trainingOnly": true
  },
  {
    "id": "EVD-016",
    "title": "Component inspection #16",
    "type": "document",
    "room": "Sector D",
    "timestamp": "02:52:28",
    "content": "The instructor reminds trainees to compare a measurement with a stated reference.",
    "unlockedBy": "SIM-004",
    "trainingOnly": true
  },
  {
    "id": "EVD-017",
    "title": "Control-room memo #17",
    "type": "recording",
    "room": "Sector D",
    "timestamp": "02:59:41",
    "content": "The drawing shows two branches connected across the same ideal source nodes.",
    "unlockedBy": "SIM-005",
    "trainingOnly": true
  },
  {
    "id": "EVD-018",
    "title": "Training worksheet #18",
    "type": "schematic",
    "room": "Sector D",
    "timestamp": "02:06:54",
    "content": "The meter's classroom calibration offset is documented as a simulated value.",
    "unlockedBy": "SIM-006",
    "trainingOnly": true
  },
  {
    "id": "EVD-019",
    "title": "Incident photograph description #19",
    "type": "measurement",
    "room": "Sector D",
    "timestamp": "02:13:07",
    "content": "Do not change multiple variables at once; preserve a clear diagnostic trail.",
    "unlockedBy": "SIM-007",
    "trainingOnly": true
  },
  {
    "id": "EVD-020",
    "title": "Relay timing log #20",
    "type": "document",
    "room": "Sector D",
    "timestamp": "02:20:20",
    "content": "The virtual branch was reported open during the previous training cycle.",
    "unlockedBy": "SIM-008",
    "trainingOnly": true
  },
  {
    "id": "EVD-021",
    "title": "Maintenance ticket #21",
    "type": "recording",
    "room": "Sector E",
    "timestamp": "02:27:33",
    "content": "The instructor reminds trainees to compare a measurement with a stated reference.",
    "unlockedBy": "SIM-009",
    "trainingOnly": true
  },
  {
    "id": "EVD-022",
    "title": "Technician audio transcript #22",
    "type": "schematic",
    "room": "Sector E",
    "timestamp": "02:34:46",
    "content": "The drawing shows two branches connected across the same ideal source nodes.",
    "unlockedBy": "SIM-010",
    "trainingOnly": true
  },
  {
    "id": "EVD-023",
    "title": "Schematic fragment #23",
    "type": "measurement",
    "room": "Sector E",
    "timestamp": "02:41:59",
    "content": "The meter's classroom calibration offset is documented as a simulated value.",
    "unlockedBy": "SIM-011",
    "trainingOnly": true
  },
  {
    "id": "EVD-024",
    "title": "Meter calibration card #24",
    "type": "document",
    "room": "Sector E",
    "timestamp": "02:48:12",
    "content": "Do not change multiple variables at once; preserve a clear diagnostic trail.",
    "unlockedBy": "SIM-012",
    "trainingOnly": true
  },
  {
    "id": "EVD-025",
    "title": "Shift handover note #25",
    "type": "recording",
    "room": "Sector E",
    "timestamp": "02:55:25",
    "content": "The virtual branch was reported open during the previous training cycle.",
    "unlockedBy": "SIM-001",
    "trainingOnly": true
  },
  {
    "id": "EVD-026",
    "title": "Component inspection #26",
    "type": "schematic",
    "room": "Sector F",
    "timestamp": "02:02:38",
    "content": "The instructor reminds trainees to compare a measurement with a stated reference.",
    "unlockedBy": "SIM-002",
    "trainingOnly": true
  },
  {
    "id": "EVD-027",
    "title": "Control-room memo #27",
    "type": "measurement",
    "room": "Sector F",
    "timestamp": "02:09:51",
    "content": "The drawing shows two branches connected across the same ideal source nodes.",
    "unlockedBy": "SIM-003",
    "trainingOnly": true
  },
  {
    "id": "EVD-028",
    "title": "Training worksheet #28",
    "type": "document",
    "room": "Sector F",
    "timestamp": "02:16:04",
    "content": "The meter's classroom calibration offset is documented as a simulated value.",
    "unlockedBy": "SIM-004",
    "trainingOnly": true
  },
  {
    "id": "EVD-029",
    "title": "Incident photograph description #29",
    "type": "recording",
    "room": "Sector F",
    "timestamp": "02:23:17",
    "content": "Do not change multiple variables at once; preserve a clear diagnostic trail.",
    "unlockedBy": "SIM-005",
    "trainingOnly": true
  },
  {
    "id": "EVD-030",
    "title": "Relay timing log #30",
    "type": "schematic",
    "room": "Sector F",
    "timestamp": "02:30:30",
    "content": "The virtual branch was reported open during the previous training cycle.",
    "unlockedBy": "SIM-006",
    "trainingOnly": true
  }
];
