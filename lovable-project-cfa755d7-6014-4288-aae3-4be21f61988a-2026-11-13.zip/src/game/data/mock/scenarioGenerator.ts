import type { MockMission, MockSeverity } from "./types";

export interface GeneratedScenario extends MockMission {
  seed: number;
  generatedAtLabel: string;
  hiddenFault: string;
  clue: string;
}

/** Seeded pseudo-random generator: same seed always yields the same training scenario. */
function seeded(seed: number) {
  let state = seed >>> 0;
  return () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

const faultBank = [
  { fault: "open_switch", clue: "The switch indicator and continuity result disagree.", concept: "Continuity" },
  { fault: "resistance_out_of_range", clue: "The measured resistance is outside the stated tolerance band.", concept: "Ohm's law" },
  { fault: "parallel_branch_open", clue: "One branch has no current while the other remains connected.", concept: "Parallel networks" },
  { fault: "relay_contact_stuck", clue: "The coil command changes but the contact state does not.", concept: "Relay logic" },
  { fault: "load_power_exceeded", clue: "The calculated load power exceeds the fictional design budget.", concept: "Power calculations" },
  { fault: "sensor_offset", clue: "Two independent virtual readings differ by a constant offset.", concept: "Measurement" },
];

const severities: MockSeverity[] = ["LOW", "MEDIUM", "HIGH", "CRITICAL"];

export function generateMockScenario(seed = 20261112): GeneratedScenario {
  const random = seeded(seed);
  const fault = faultBank[Math.floor(random() * faultBank.length)]!;
  const voltage = [5, 9, 12, 18, 24][Math.floor(random() * 5)]!;
  const resistance = [100, 220, 330, 470, 680, 1000, 2200][Math.floor(random() * 7)]!;
  const severity = severities[Math.floor(random() * severities.length)]!;
  const serial = String(seed >>> 0).slice(-6).padStart(6, "0");
  return {
    id: `GEN-${serial}`,
    title: `Generated ${fault.concept} Drill`,
    chapter: 4,
    difficulty: severity,
    concept: fault.concept,
    faultType: fault.fault,
    scene: "A fictional low-voltage training rig reports an unexpected result. Inspect the evidence before choosing a diagnosis.",
    sourceVoltageV: voltage,
    nominalResistanceOhm: resistance,
    expectedCurrentA: Number((voltage / resistance).toFixed(6)),
    timeLimitSeconds: 180,
    points: 150,
    tags: ["generated", "seeded", fault.fault],
    trainingOnly: true,
    seed,
    generatedAtLabel: "DETERMINISTIC DEMO SCENARIO",
    hiddenFault: fault.fault,
    clue: fault.clue,
  };
}
