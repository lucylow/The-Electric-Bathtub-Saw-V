import type { MockMission } from "./types";

export const mockMissions: MockMission[] = [
  {
    "id": "SIM-001",
    "title": "The Open Loop",
    "chapter": 1,
    "difficulty": "LOW",
    "concept": "Continuity",
    "faultType": "open_path",
    "scene": "A lamp branch does not complete its virtual loop.",
    "sourceVoltageV": 5,
    "nominalResistanceOhm": 100,
    "expectedCurrentA": 0.05,
    "timeLimitSeconds": 180,
    "points": 125,
    "tags": [
      "continuity",
      "virtual-dc",
      "low"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-002",
    "title": "The Resistance Drift",
    "chapter": 1,
    "difficulty": "MEDIUM",
    "concept": "Ohm's law",
    "faultType": "resistance_drift",
    "scene": "Measured current differs from the expected DC model.",
    "sourceVoltageV": 9,
    "nominalResistanceOhm": 220,
    "expectedCurrentA": 0.04091,
    "timeLimitSeconds": 210,
    "points": 150,
    "tags": [
      "ohm's-law",
      "virtual-dc",
      "medium"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-003",
    "title": "The Divided Corridor",
    "chapter": 1,
    "difficulty": "MEDIUM",
    "concept": "Series network",
    "faultType": "voltage_division",
    "scene": "Two loads share one virtual current path.",
    "sourceVoltageV": 12,
    "nominalResistanceOhm": 330,
    "expectedCurrentA": 0.03636,
    "timeLimitSeconds": 240,
    "points": 175,
    "tags": [
      "series-network",
      "virtual-dc",
      "medium"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-004",
    "title": "The Last Branch",
    "chapter": 1,
    "difficulty": "HIGH",
    "concept": "Parallel network",
    "faultType": "branch_open",
    "scene": "One branch opens while the other remains available.",
    "sourceVoltageV": 18,
    "nominalResistanceOhm": 470,
    "expectedCurrentA": 0.0383,
    "timeLimitSeconds": 150,
    "points": 100,
    "tags": [
      "parallel-network",
      "virtual-dc",
      "high"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-005",
    "title": "The Stuck Armature",
    "chapter": 2,
    "difficulty": "HIGH",
    "concept": "Relay logic",
    "faultType": "relay_contact",
    "scene": "The relay coil and controlled contact disagree.",
    "sourceVoltageV": 24,
    "nominalResistanceOhm": 680,
    "expectedCurrentA": 0.03529,
    "timeLimitSeconds": 180,
    "points": 125,
    "tags": [
      "relay-logic",
      "virtual-dc",
      "high"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-006",
    "title": "The Hidden Path",
    "chapter": 2,
    "difficulty": "CRITICAL",
    "concept": "Fault isolation",
    "faultType": "unintended_path",
    "scene": "A hidden low-resistance path changes total current.",
    "sourceVoltageV": 6,
    "nominalResistanceOhm": 1000,
    "expectedCurrentA": 0.006,
    "timeLimitSeconds": 210,
    "points": 150,
    "tags": [
      "fault-isolation",
      "virtual-dc",
      "critical"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-007",
    "title": "The Overloaded Console",
    "chapter": 2,
    "difficulty": "HIGH",
    "concept": "Power budget",
    "faultType": "overload",
    "scene": "The sum of virtual load power exceeds the design budget.",
    "sourceVoltageV": 5,
    "nominalResistanceOhm": 100,
    "expectedCurrentA": 0.05,
    "timeLimitSeconds": 240,
    "points": 175,
    "tags": [
      "power-budget",
      "virtual-dc",
      "high"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-008",
    "title": "The Misleading Meter",
    "chapter": 2,
    "difficulty": "LOW",
    "concept": "Sensor calibration",
    "faultType": "sensor_offset",
    "scene": "A simulated meter reports a consistent offset.",
    "sourceVoltageV": 9,
    "nominalResistanceOhm": 220,
    "expectedCurrentA": 0.04091,
    "timeLimitSeconds": 150,
    "points": 100,
    "tags": [
      "sensor-calibration",
      "virtual-dc",
      "low"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-009",
    "title": "The Wrong Guardian",
    "chapter": 3,
    "difficulty": "CRITICAL",
    "concept": "Fuse coordination",
    "faultType": "protection_mismatch",
    "scene": "The virtual protection choice does not match the modeled load.",
    "sourceVoltageV": 12,
    "nominalResistanceOhm": 330,
    "expectedCurrentA": 0.03636,
    "timeLimitSeconds": 180,
    "points": 125,
    "tags": [
      "fuse-coordination",
      "virtual-dc",
      "critical"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-010",
    "title": "The First Pulse",
    "chapter": 3,
    "difficulty": "MEDIUM",
    "concept": "Transient response",
    "faultType": "startup_surge",
    "scene": "A short startup event differs from steady-state current.",
    "sourceVoltageV": 18,
    "nominalResistanceOhm": 470,
    "expectedCurrentA": 0.0383,
    "timeLimitSeconds": 210,
    "points": 150,
    "tags": [
      "transient-response",
      "virtual-dc",
      "medium"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-011",
    "title": "The Floating Reference",
    "chapter": 3,
    "difficulty": "HIGH",
    "concept": "Ground reference",
    "faultType": "reference_shift",
    "scene": "Measurements use inconsistent virtual reference nodes.",
    "sourceVoltageV": 24,
    "nominalResistanceOhm": 680,
    "expectedCurrentA": 0.03529,
    "timeLimitSeconds": 240,
    "points": 175,
    "tags": [
      "ground-reference",
      "virtual-dc",
      "high"
    ],
    "trainingOnly": true
  },
  {
    "id": "SIM-012",
    "title": "The Tolerance Trap",
    "chapter": 3,
    "difficulty": "MEDIUM",
    "concept": "Component tolerance",
    "faultType": "tolerance_stack",
    "scene": "Several component tolerances combine into a wider range.",
    "sourceVoltageV": 6,
    "nominalResistanceOhm": 1000,
    "expectedCurrentA": 0.006,
    "timeLimitSeconds": 150,
    "points": 100,
    "tags": [
      "component-tolerance",
      "virtual-dc",
      "medium"
    ],
    "trainingOnly": true
  }
];
