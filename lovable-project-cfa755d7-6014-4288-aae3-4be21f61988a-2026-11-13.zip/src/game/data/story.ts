import type { Discovery } from "../types";

export const discoveries: Discovery[] = [
  { id: "note-01", title: "MAINTENANCE NOTE 04", category: "document", found: false,
    body: "The west control panel has been disconnected for inspection. The open terminal is intentional. Do not confuse an inactive indicator with a failed source." },
  { id: "diagram-01", title: "HAND-DRAWN SCHEMATIC", category: "clue", found: false,
    body: "A closed loop is required before the virtual indicator can illuminate. Trace the return path. A wire that looks connected may terminate at a different node." },
  { id: "log-01", title: "RECOVERED AUDIO LOG", category: "recording", found: false,
    body: "Technician: 'The first lock is not difficult. That is what makes it cruel. Everyone rushes. Nobody checks continuity.' [END OF RECORDING]" },
  { id: "memo-02", title: "MERIDIAN INSTITUTE MEMO", category: "document", found: false,
    body: "Experiment 001 evaluates observation before intervention. Participants are scored on diagnosis, not speed. The facility's countdown is theatrical in Story Mode." },
  { id: "photo-02", title: "PHOTOGRAPH: CONTROL ROOM", category: "clue", found: false,
    body: "Five numbered stations surround a central console. The sixth position is scratched away. A handwritten annotation reads: 'The system is watching the observer.'" },
  { id: "log-02", title: "ENGINEER // TRANSMISSION", category: "recording", found: false,
    body: "You found the return path. Good. A machine is honest about what it needs. People are less reliable." },
  { id: "memo-03", title: "INCIDENT REPORT 11-B", category: "document", found: false,
    body: "No live electrical equipment is installed in the test chamber. All participant-facing electrical experiments are isolated software simulations. Physical props are inert." },
  { id: "clue-03", title: "ETCHED INTO THE PANEL", category: "clue", found: false,
    body: "V = I × R. The symbols are not decoration. Measure before you guess." },
  { id: "log-03", title: "FINAL VOICE FRAGMENT", category: "recording", found: false,
    body: "The first door was never the exit. It was an invitation to keep asking better questions." },
  { id: "memo-04", title: "SUBJECT EVALUATION", category: "document", found: false,
    body: "The subject demonstrated improved fault isolation after documenting each failed hypothesis. Recommendation: preserve the notebook between experiments." }
];

export const engineerLines = {
  intro: "Good evening. I see you have an interest in electricity. Tonight, you will discover what happens when you fail to understand it.",
  firstInspect: "Look carefully. The room is not hiding the answer. It is hiding the question.",
  wrong: "An assumption is not a measurement. Try again.",
  success: "A complete path. The indicator is awake. One lock has released.",
  allDone: "Five circuits. Five observations. You have learned how this place thinks. Now ask why it was built."
};