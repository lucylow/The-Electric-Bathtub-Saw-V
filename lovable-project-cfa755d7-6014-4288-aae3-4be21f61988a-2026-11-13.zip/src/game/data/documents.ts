export const archiveDocuments = [
  { id:"M-001", title:"Facility access log", text:"The lower laboratory was sealed after Experiment 011. Access requires a five-stage diagnostic release." },
  { id:"M-002", title:"Equipment isolation statement", text:"All equipment visible to participants is inert. Interactive electrical behaviour is simulated in software." },
  { id:"M-003", title:"Technician's pocket guide", text:"Observe. Predict. Measure. Compare. Explain. Do not skip the explanation." },
  { id:"M-004", title:"Night shift handover", text:"The CRT may activate without a user interaction. This is a scripted narrative event." },
  { id:"M-005", title:"Subject evaluation rubric", text:"Correct answers receive credit. Clear reasoning receives additional credit. Hints reduce the no-assistance bonus." },
  { id:"M-006", title:"Meridian Institute memo", text:"The facility's systems should be understood as one connected narrative environment. Restoring a subsystem can reveal another clue." },
  { id:"M-007", title:"Incident review", text:"A previous participant repeatedly changed several variables at once. The resulting diagnosis was inconclusive." },
  { id:"M-008", title:"Audio archive index", text:"Recordings are fragments. Their timestamps may be unreliable. The engineering diagrams remain the authoritative puzzle references." },
  { id:"M-009", title:"Control-room diagram", text:"Five lock stations report status to a central console. The exit indicator is a separate mechanical state." },
  { id:"M-010", title:"Final note", text:"The sixth experiment is not a circuit. It is the decision to question the experiment itself." }
];