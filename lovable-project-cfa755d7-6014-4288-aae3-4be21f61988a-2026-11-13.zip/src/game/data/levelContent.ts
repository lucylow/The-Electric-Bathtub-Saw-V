import { lockLessons } from "./puzzles";
export const levelContent = lockLessons.map((lesson, index) => ({
  id: `experiment-${String(index+1).padStart(3,"0")}`,
  number: index + 1,
  ...lesson,
  briefing: [
    "The first connection is incomplete. Trace the loop before touching the controls.",
    "The cabinet contains resistors with different values. Predict the current before selecting a load.",
    "Five branches appear independent. Measure each path and compare the node currents.",
    "The magnetic door is controlled by a relay. Separate the control signal from the switched load.",
    "The master system contains a hidden fault. Record evidence, form a hypothesis and test it."
  ][index],
  reward: 100 + index * 50
}));