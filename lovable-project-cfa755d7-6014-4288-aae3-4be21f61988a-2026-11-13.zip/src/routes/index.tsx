import { createFileRoute } from "@tanstack/react-router";
import gameCss from "@/game/game.css?url";
import { useEffect, useRef, useState } from "react";
import { BookOpen, ClipboardList, Settings as SettingsIcon, Volume2, VolumeX, Zap, Menu, X, LockKeyhole, RadioTower, Activity, ShieldAlert, Database as DatabaseIcon, GraduationCap } from "lucide-react";
import Room from "@/game/components/Room";
import CircuitPanel from "@/game/components/CircuitPanel";
import Notebook from "@/game/components/Notebook";
import Settings from "@/game/components/Settings";
import EngineeringWorkbench from "@/game/components/EngineeringWorkbench";
import IncidentResponse from "@/game/components/IncidentResponse";
import MockDataLab from "@/game/components/MockDataLab";
import Academy from "@/game/components/Academy";
import { useGameStore } from "@/game/store/gameStore";
import { engineerLines } from "@/game/data/story";
import { lockLessons } from "@/game/data/puzzles";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "The Electric Bathtub // Experiment 001" },
      { name: "description", content: "A psychological horror circuit-puzzle game. Five circuits. Five locks. One way out." },
      { property: "og:title", content: "The Electric Bathtub // Experiment 001" },
      { property: "og:description", content: "Five circuits. Five locks. One way out. A psychological horror engineering puzzle." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" }, { rel: "stylesheet", href: gameCss }],
  }),
  component: App,
});

function App() {
  const [intro,setIntro]=useState(true);
  const [circuit,setCircuit]=useState(false);
  const [notebook,setNotebook]=useState(false);
  const [settings,setSettings]=useState(false);
  const [workbench,setWorkbench]=useState(false);
  const [incident,setIncident]=useState(false);
  const [mockData,setMockData]=useState(false);
  const [academy,setAcademy]=useState(false);
  const [muted,setMuted]=useState(true);
  const [showMenu,setShowMenu]=useState(false);
  const {started,start,load,unlockedLocks,score,attempts,message,completed,reducedMotion}=useGameStore();
  useEffect(()=>{load();},[load]);
  const begin=()=>{start();setIntro(false);};
  const openCircuit=()=>setCircuit(true);
  const anyOpen=circuit||notebook||settings||workbench||incident||mockData||academy;
  const closeAll=()=>{setCircuit(false);setNotebook(false);setSettings(false);setWorkbench(false);setIncident(false);setMockData(false);setAcademy(false);setShowMenu(false);};
  useEffect(()=>{
    const onKey=(e:KeyboardEvent)=>{
      const t=e.target as HTMLElement|null;
      if(t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA"||t.tagName==="SELECT"))return;
      if(e.key==="Escape"){closeAll();return;}
      if(intro){if(e.key==="Enter"){e.preventDefault();begin();}return;}
      if(anyOpen||e.metaKey||e.ctrlKey||e.altKey)return;
      const k=e.key.toLowerCase();
      if(k==="e")setCircuit(true);else if(k==="n")setNotebook(true);else if(k==="w")setWorkbench(true);else if(k==="a")setAcademy(true);
    };
    window.addEventListener("keydown",onKey);return()=>window.removeEventListener("keydown",onKey);
  });
  useEffect(()=>{document.body.style.overflow=anyOpen?"hidden":"";},[anyOpen]);
  // Focus management: trap focus inside the open window, restore to the trigger on close.
  const returnFocus=useRef<HTMLElement|null>(null);
  const menuButton=useRef<HTMLButtonElement>(null);
  useEffect(()=>{
    if(!anyOpen)return;
    const active=document.activeElement as HTMLElement|null;
    returnFocus.current=active&&active!==document.body&&!active.closest(".quick-menu")?active:menuButton.current;
    const sel='button:not([disabled]),[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
    const getOverlay=()=>Array.from(document.querySelectorAll<HTMLElement>(".panel-overlay")).pop();
    const items=()=>{const o=getOverlay();return o?Array.from(o.querySelectorAll<HTMLElement>(sel)).filter(el=>el.offsetParent!==null||el===document.activeElement):[];};
    requestAnimationFrame(()=>{const o=getOverlay();if(o&&!o.contains(document.activeElement)){const f=items();(f.find(el=>!el.classList.contains("icon-button"))??f[0]??o).focus();}});
    const onTab=(e:KeyboardEvent)=>{
      if(e.key!=="Tab")return;
      const o=getOverlay();if(!o)return;
      const f=items();if(!f.length){e.preventDefault();return;}
      const first=f[0]!,last=f[f.length-1]!,cur=document.activeElement as HTMLElement|null;
      if(!cur||!o.contains(cur)){e.preventDefault();(e.shiftKey?last:first).focus();}
      else if(e.shiftKey&&cur===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey&&cur===last){e.preventDefault();first.focus();}
    };
    const onFocusIn=(e:FocusEvent)=>{const o=getOverlay();if(o&&!o.contains(e.target as Node))items()[0]?.focus();};
    document.addEventListener("keydown",onTab);document.addEventListener("focusin",onFocusIn);
    return()=>{
      document.removeEventListener("keydown",onTab);document.removeEventListener("focusin",onFocusIn);
      const el=returnFocus.current;
      requestAnimationFrame(()=>{(el&&el.isConnected?el:menuButton.current)?.focus();});
    };
  },[anyOpen]);
  return <main className={`game-shell${reducedMotion?" reduced-motion":""}`} onMouseDown={e=>{if((e.target as HTMLElement).classList.contains("panel-overlay"))closeAll();}}>
    <header className="hud-top">
      <div className="brand"><span className="brand-mark"><Zap size={17}/></span><div><b>THE ELECTRIC BATHTUB</b><small>MERIDIAN INSTITUTE / EXPERIMENT 001</small></div></div>
      <div className="hud-center"><span className="live-dot"/> SYSTEM STATUS: <b>{completed?"EXPERIMENT COMPLETE":"CONTAINMENT ACTIVE"}</b></div>
      <div className="hud-actions"><button onClick={()=>setAcademy(true)} title="Engineering academy"><GraduationCap/></button><button onClick={()=>setNotebook(true)} title="Notebook"><BookOpen/></button><button onClick={()=>setWorkbench(true)} title="Engineering workbench"><Activity/></button><button onClick={()=>setIncident(true)} title="Incident response simulator"><ShieldAlert/></button><button onClick={()=>setMockData(true)} title="Mock data control room"><DatabaseIcon/></button><button onClick={()=>setSettings(true)} title="Settings"><SettingsIcon/></button><button onClick={()=>setMuted(v=>!v)} title="Audio">{muted?<VolumeX/>:<Volume2/>}</button><button ref={menuButton} onClick={()=>setShowMenu(v=>!v)} title="Menu" aria-label="Menu" aria-expanded={showMenu}>{showMenu?<X/>:<Menu/>}</button></div>
    </header>
    {showMenu && <div className="quick-menu"><button onClick={()=>{setNotebook(true);setShowMenu(false)}}>ENGINEERING NOTEBOOK</button><button onClick={()=>{setWorkbench(true);setShowMenu(false)}}>ENGINEERING WORKBENCH</button><button onClick={()=>{setIncident(true);setShowMenu(false)}}>INCIDENT RESPONSE</button><button onClick={()=>{setMockData(true);setShowMenu(false)}}>MOCK DATA CONTROL ROOM</button><button onClick={()=>{setSettings(true);setShowMenu(false)}}>SUBJECT SETTINGS</button><button onClick={()=>{setIntro(true);setShowMenu(false)}}>RETURN TO TITLE</button></div>}
    <div className="game-layout">
      <aside className="left-rail">
        <div className="rail-heading">EXPERIMENT<br/><strong>001</strong></div>
        <div className="rail-divider"/>
        <div className="objective-label">PRIMARY OBJECTIVE</div>
        <p className="objective-text">{completed?"The exit mechanism has released.":`Restore the five virtual lock systems to release the exit.`}</p>
        <div className="lock-progress">{lockLessons.map((lesson,i)=><div className={`progress-lock ${unlockedLocks.includes(i)?"done":i===unlockedLocks.length?"current":""}`} key={lesson.title}><span className="lock-index">0{i+1}</span><div><b>{lesson.title}</b><small>{lesson.concept}</small></div><i>{unlockedLocks.includes(i)?"✓":<LockKeyhole size={13}/>}</i></div>)}</div>
        <div className="rail-bottom"><span>SUBJECT SCORE</span><b>{score.toString().padStart(4,"0")}</b><span>DIAGNOSTIC ATTEMPTS: {attempts}</span></div>
      </aside>
      <section className="main-stage">
        <div className="stage-header"><span><RadioTower size={13}/> LIVE ENVIRONMENT FEED</span><span>CAMERA 04 / 1080P <i/></span></div>
        <div className="mobile-progress" aria-label={`${unlockedLocks.length} of 5 locks released`}>{lockLessons.map((l,i)=><span key={l.title} className={unlockedLocks.includes(i)?"done":i===unlockedLocks.length?"current":""}/>)}<b>{unlockedLocks.length}/5 LOCKS · NEXT: {lockLessons[unlockedLocks.length]?.title ?? "EXIT RELEASED"}</b></div>
        <Room onOpenCircuit={openCircuit}/>
        <div className="status-bar"><span className="status-square"/> <b>{message}</b><span className="status-right">VIRTUAL SYSTEMS ONLY / LOW-VOLTAGE MODEL</span></div>
      </section>
      <aside className="right-rail">
        <div className="right-section"><span className="eyebrow">SUBJECT PROFILE</span><div className="subject-card"><div className="subject-avatar">E-<b>01</b></div><div><b>UNKNOWN SUBJECT</b><small>ENGINEERING TRAINEE</small></div></div></div>
        <div className="right-section"><span className="eyebrow">THE ENGINEER</span><div className="engineer-card"><div className="engineer-noise">▧ ▨ ▧</div><p>{completed?engineerLines.allDone:unlockedLocks.length?engineerLines.success:engineerLines.firstInspect}</p><span>— INCOMING TRANSMISSION</span></div></div>
        <div className="right-section"><span className="eyebrow">FACILITY LOG</span><div className="facility-log"><p><i/> {unlockedLocks.length} / 5 LOCKS RELEASED</p><p><i/> {attempts} DIAGNOSTIC RUNS</p><p><i/> {score} EVALUATION POINTS</p></div></div>
        <button className="notebook-cta" onClick={()=>setAcademy(true)}><GraduationCap size={17}/> ENTER ENGINEERING ACADEMY <span>↗</span></button>
        <button className="notebook-cta" onClick={()=>setNotebook(true)}><ClipboardList size={17}/> OPEN EXPERIMENT LOG <span>↗</span></button>
      </aside>
    </div>
    <footer className="game-footer"><span>THE ELECTRIC BATHTUB <i>©</i> // INTERACTIVE ENGINEERING FICTION</span><span className="key-legend">KEYS: E CONSOLE · N NOTEBOOK · W WORKBENCH · A ACADEMY · ESC CLOSE</span><span>DO NOT ATTEMPT REAL-WORLD ELECTRICAL WORK</span></footer>
    {intro && <div className="intro-overlay"><div className="intro-grain"/><div className="intro-content"><div className="intro-overline"><span/> MERIDIAN INSTITUTE PRESENTS <span/></div><h1>THE ELECTRIC<br/><em>BATHTUB</em></h1><p className="intro-tagline">FIVE CIRCUITS. FIVE LOCKS. ONE WAY OUT.</p><div className="intro-tv"><div className="intro-static">▧ ░ ▨ ▒ ░ ▧ ▒ ▨ ░ ▧</div><p>“{engineerLines.intro}”</p><span>— THE ENGINEER / TRANSMISSION 001</span></div><button className="begin-button" onClick={begin}>{unlockedLocks.length||attempts?"CONTINUE EXPERIMENT":"BEGIN EXPERIMENT"} <span>→</span></button><div className="intro-keyhint">PRESS ENTER ↵</div><div className="intro-disclaimer">PSYCHOLOGICAL HORROR / ELECTRICAL ENGINEERING SIMULATION<br/>ALL ELECTRICAL SYSTEMS ARE FICTIONAL AND VIRTUAL</div></div></div>}
    {circuit && <CircuitPanel onClose={()=>setCircuit(false)}/>}
    {notebook && <Notebook onClose={()=>setNotebook(false)}/>}
    {settings && <Settings onClose={()=>setSettings(false)}/>}
    {workbench && <EngineeringWorkbench onClose={()=>setWorkbench(false)}/>}
    {incident && <IncidentResponse onClose={()=>setIncident(false)}/>}
    {mockData && <MockDataLab onClose={()=>setMockData(false)}/>}
    {academy && <Academy onClose={()=>setAcademy(false)}/>}
  </main>;
}