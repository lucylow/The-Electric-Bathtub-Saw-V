# Lovable continuation prompt

Continue building **THE ELECTRIC BATHTUB — Experiment 001** from this repository. Do not replace the horror identity with a dashboard or quiz.

## Preserve
- Industrial psychological horror: charcoal, dirty concrete, corroded metal, emergency red, cold cyan.
- The Engineer as an unseen antagonist through CRT transmissions, notes and audio fragments.
- Five experiments: continuity, Ohm's law, series/parallel, relays/electromagnetism, system fault diagnosis.
- The bathtub is decorative and electrically isolated.
- The player solves software-only virtual circuits; never model a person or real bathtub as an electrical load.

## Implement next, in order
1. Convert the CSS room into a React Three Fiber scene with modular geometry, baked lighting, fog, dust and a CRT shader.
2. Add a desktop first-person controller: WASD, pointer lock, mouse look, sprint toggle, interaction raycast, Escape to release pointer lock. Add a clear keyboard-control overlay.
3. Replace the first circuit schematic with a true node-and-edge editor. Keep the current single-loop solver as the reference case and add tested solver modules incrementally.
4. Implement the other four experiments as validated puzzle definitions. Every puzzle must include a learning objective, schematic, deterministic expected answer, hint ladder, failure explanation and debrief.
5. Add an engineering notebook that records discoveries, calculations, measurements, hypotheses and mistakes.
6. Add narrative event orchestration: CRT flicker, lights dip, mechanical door movement, silence and final transmission. Events must be state-triggered, not random jump scares.
7. Add original audio assets or clearly marked placeholders; provide volume sliders, subtitles and reduced-flashing controls.
8. Add versioned saves, recovery after refresh, progress migration and automated tests.
9. Add mobile fallback controls and a quality selector. Desktop remains the primary experience.
10. Polish the exit sequence and a final debrief that explains the concepts learned.

## Engineering requirements
- Keep simulation calculations deterministic and testable.
- Clearly label simplified educational models.
- Do not invent meter readings in tutor dialogue; derive explanations from solver output.
- Never reward a physically invalid circuit merely because it matches a hard-coded button sequence.
- No instructions for wiring mains electricity, human-body current paths, electrocution or bypassing safety devices.
- Add tests for every accepted puzzle solution and representative invalid states.
- Keep the project buildable after every milestone.
