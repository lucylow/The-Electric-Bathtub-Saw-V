# Engineering Workbench — Expansion Pack

This update extends The Electric Bathtub without replacing its original five-lock progression.

## New player-facing feature

A new **Engineering Workbench** button appears in the top HUD. It opens a separate fault-analysis training surface with four selectable virtual fault reports:

1. **Open Contact** — demonstrates an interrupted path and zero steady-state current.
2. **Overcurrent** — compares calculated current against a simulated fuse rating.
3. **Low Supply** — shows a continuous circuit that remains below the exercise's operating threshold.
4. **Power Budget** — compares load dissipation against a fictional 10 W training limit.

Players can adjust the model's voltage, resistance, fuse rating, and switch state. The meters update live; the diagnostic explanation appears after the player selects **Run Fault Diagnostic**. Case reset restores the selected case's baseline values.

## Educational model

The workbench uses the existing `calculateOhms` helper:

- Current: `I = V / R`
- Power: `P = V × I`
- Open switch: current is explicitly set to zero in the displayed result.
- Protection trip: calculated current exceeds the selected simulated fuse rating.
- Power fault: calculated load power exceeds the exercise's fictional 10 W threshold.
- Undervoltage: source is below the exercise's fictional 5 V indicator threshold.

The 5 V and 10 W thresholds are game rules, not universal component specifications. This is a simplified educational model and is not suitable for real circuit design or electrical work.

## Files changed

- `src/App.tsx` — adds the workbench modal state, HUD entry point, and component mount.
- `src/components/EngineeringWorkbench.tsx` — new self-contained workbench and scenario logic.
- `src/styles.css` — responsive styling for the new workbench.

## Run locally

```bash
npm install
npm run dev
```

Build verification:

```bash
npm run build
npm test
```

## Suggested next development increment

The next major milestone should be a genuine first-person environment using the already-installed Three.js / React Three Fiber stack: pointer-lock camera, WASD navigation, keyboard-accessible interaction fallback, interactable console, original ambient audio, and a short guided tutorial. Keep the circuit calculations deterministic and independent from the rendering layer.
