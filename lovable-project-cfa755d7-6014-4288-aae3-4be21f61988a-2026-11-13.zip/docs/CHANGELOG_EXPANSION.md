# Expansion changelog

## 1.1.0 — Engineering Workbench

- Added four guided fault-analysis scenarios.
- Added adjustable virtual voltage, resistance, fuse rating, and switch state.
- Added live current, power, and resistance readouts.
- Added explicit diagnostic-run step and explanatory feedback.
- Added reset-to-case-baseline behavior.
- Added responsive layouts for narrow screens.
- Added an explicit virtual-model safety notice.
- Kept the existing five-lock campaign and save format unchanged.
