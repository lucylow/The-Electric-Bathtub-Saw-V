# Implementation backlog — 120 engineering tasks
Each item is an actionable implementation or validation task for the Lovable project.
001. Define the interaction contract for every room hotspot.
002. Add keyboard focus indicators to all interactive props.
003. Implement pointer-lock acquisition only after explicit user action.
004. Implement pointer-lock release on Escape and when opening a modal.
005. Add collision boundaries for the room's walls and large props.
006. Add configurable movement speed and sprint stamina-free mode.
007. Add an interaction raycast layer with priority ordering.
008. Add interaction prompts with keyboard remapping.
009. Add a pause state that freezes gameplay timers.
010. Add a title-screen continue button when a valid save exists.
011. Add a versioned save migration registry.
012. Add save corruption recovery with a user-facing explanation.
013. Add a manual save export and import feature.
014. Add a local save reset confirmation dialog.
015. Add a game-state event log for debugging.
016. Add deterministic event triggers for the CRT sequence.
017. Add a cinematic subtitle timeline.
018. Add skip-cinematic support after the first viewing.
019. Add subtitle speaker labels and timing.
020. Add audio bus controls for ambience, effects and voice.
021. Add an audio mute toggle that persists.
022. Add an audio calibration screen.
023. Add reduced-flashing mode.
024. Add reduced-motion mode.
025. Add adjustable vignette intensity.
026. Add a high-contrast interaction mode.
027. Add scalable interface text.
028. Add keyboard-only navigation for all panels.
029. Add screen-reader labels for diagnostic values.
030. Add color-independent lock states using icons and text.
031. Add a component registry with validated metadata.
032. Add units to every component value.
033. Reject negative resistance values.
034. Reject non-finite simulation inputs.
035. Represent circuit nodes with stable identifiers.
036. Represent circuit branches with stable identifiers.
037. Represent components as typed edges.
038. Add a graph connectivity traversal for continuity.
039. Add a disconnected-node diagnostic.
040. Add a source polarity model for the virtual DC source.
041. Add a switch state model with explicit contact state.
042. Add resistor voltage-drop calculations.
043. Add a series resistance reference solver.
044. Add a parallel resistance reference solver.
045. Add Kirchhoff current law validation cases.
046. Add Kirchhoff voltage law validation cases.
047. Add branch current readouts for parallel networks.
048. Add power calculations and unit formatting.
049. Add a component power-rating educational check.
050. Add a fuse-rating conceptual simulation.
051. Add diode polarity as a later isolated puzzle model.
052. Add relay coil/contact state as a later isolated puzzle model.
053. Add capacitor transient model only after DC solver tests.
054. Add inductor transient model only after DC solver tests.
055. Document all solver assumptions in the UI.
056. Display solver errors separately from puzzle failure.
057. Display measurement uncertainty in an advanced lesson.
058. Add a multimeter tool with voltage, resistance and continuity modes.
059. Add a virtual oscilloscope with a static sample waveform.
060. Add a timebase control for the oscilloscope.
061. Add a voltage scale control for the oscilloscope.
062. Add a trigger-level control for the oscilloscope.
063. Add a fault injection seed for reproducible puzzles.
064. Add open-connection fault scenarios.
065. Add incorrect-component-value fault scenarios.
066. Add reversed-diode fault scenarios.
067. Add failed-switch fault scenarios.
068. Add a fault diagnosis notebook template.
069. Add hypothesis recording before simulation.
070. Add a prediction field before the Run button.
071. Compare predicted and measured values after simulation.
072. Reward a correct explanation in addition to a correct result.
073. Add hint tiers that reveal concepts before answers.
074. Track hint use per puzzle rather than globally only.
075. Add story mode with no countdown pressure.
076. Add engineering mode with limited hints.
077. Add nightmare mode with optional timer pressure.
078. Make all timer pressure disabled by default for accessibility.
079. Add a timer pause when the player opens the notebook.
080. Add five independent lock state machines.
081. Add a central exit state machine.
082. Prevent lock state from being changed by UI-only shortcuts.
083. Require a validated puzzle completion event to release a lock.
084. Add a final exit animation after all locks release.
085. Add a recovery path if the exit animation is interrupted.
086. Add a level select screen after completing Experiment 001.
087. Add a debrief page for continuity and Ohm's law.
088. Add a concept mastery summary based on demonstrated work.
089. Add an optional practice mode without horror events.
090. Add a new-game-plus puzzle seed.
091. Add a local leaderboard based on score and time.
092. Do not upload player analytics without explicit consent.
093. Add a privacy settings explanation.
094. Add a data deletion control for local progress.
095. Add a credits page for all original and third-party assets.
096. Track asset licenses in an asset manifest.
097. Use original antagonist dialogue rather than copied film dialogue.
098. Review game title and marketing for trademark confusion.
099. Use original audio recordings or properly licensed audio.
100. Use original environmental textures or properly licensed assets.
101. Add a visual asset loading fallback.
102. Add a low-quality graphics mode.
103. Add a texture resolution setting.
104. Add a shadow quality setting.
105. Add an adaptive device pixel ratio cap.
106. Add lazy loading for later rooms.
107. Add instancing for repeated bolts and pipes.
108. Add geometry reuse for repeated lock housings.
109. Add a performance overlay for development builds only.
110. Add a target frame-rate test on representative devices.
111. Add browser compatibility smoke tests.
112. Add a responsive mobile layout for notebook and circuit panels.
113. Add touch-friendly switch controls.
114. Add a mobile movement joystick only after desktop controller is stable.
115. Add a mobile interaction button.
116. Add a controller input abstraction.
117. Add remappable keyboard bindings.
118. Add an input conflict test for menus and movement.
119. Add a loading state for 3D assets.
120. Add a missing-asset error screen.
121. Add a deterministic screenshot test for the title screen.
122. Add a deterministic screenshot test for the room.
123. Add unit tests for progression rules.
124. Add unit tests for save migration.
125. Add integration tests for lock release.
126. Add integration tests for final completion.
127. Add end-to-end test for the first experiment.
128. Add test coverage for all hint branches.
129. Add test coverage for corrupted local saves.
130. Add a production build check to CI.
131. Add TypeScript strict checks to CI.
132. Add lint and formatting checks to CI.
133. Add an engineering content review checklist.
134. Add an accessibility review checklist.
135. Add a horror pacing playtest checklist.
136. Add a player comprehension test for Ohm's law.
137. Add a player comprehension test for open and closed circuits.
138. Add a review of every electrical statement for accuracy.
139. Add a release checklist for privacy, licensing and browser support.
